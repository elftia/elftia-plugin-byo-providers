/** Non-secret configuration for one host-managed object storage instance. */
export interface HostObjectStorageProviderConfig {
  readonly bucket: string;
  readonly region?: string;
  readonly endpoint?: string;
  readonly prefix?: string;
  readonly publicBaseUrl?: string;
  readonly urlMode: 'signed' | 'public';
  readonly expiresInSeconds?: number;
  readonly forcePathStyle?: boolean;
}

/**
 * Masked instance descriptor. Credentials never cross this port.
 *
 * v2 (host 2.6): storage is modeled as N user-created named instances — the
 * same template (e.g. Cloudflare R2) may appear multiple times with different
 * buckets. `id` is `"<templateId>~<suffix>"`, `templateId` names the builtin
 * family, and `enabled` is the per-instance toggle mirroring the model/media
 * provider switches. Legacy fixed slots migrated to `<templateId>~base`.
 */
export interface HostObjectStorageProvider {
  readonly id: string;
  readonly templateId: string;
  readonly name: string;
  readonly description: string;
  readonly kind: 's3' | 'oss';
  /** User-created instances are `false`; kept for the legacy fixed slots. */
  readonly builtin: boolean;
  readonly isDefault: boolean;
  readonly enabled: boolean;
  readonly configured: boolean;
  readonly ready: boolean;
  readonly config: HostObjectStorageProviderConfig;
  readonly accessKeyId?: never;
  readonly secretAccessKey?: never;
  readonly sessionToken?: never;
}

export type HostObjectStorageProviderPatch = Partial<
  HostObjectStorageProviderConfig & { name: string; enabled: boolean }
>;

/** Write-only credentials. Empty/omitted fields leave the stored value unchanged. */
export interface HostObjectStorageCredentialsInput {
  readonly accessKeyId?: string;
  readonly secretAccessKey?: string;
  readonly sessionToken?: string;
}

export interface HostObjectStorageMutationResult {
  readonly success: boolean;
  readonly provider?: HostObjectStorageProvider;
  readonly error?: string;
}

/**
 * `host.services.objectStorageConfig` — BYO object-storage configuration port.
 * Templates: `aws-s3` | `cloudflare-r2` | `aliyun-oss` | `s3-compatible`.
 */
export interface HostObjectStorageConfigLike {
  listProviders(): Promise<readonly HostObjectStorageProvider[]>;
  /** Create a new instance from a builtin template (2.6). */
  addProvider(
    templateId: string,
    name?: string
  ): Promise<HostObjectStorageMutationResult>;
  updateProvider(
    id: string,
    patch: HostObjectStorageProviderPatch
  ): Promise<HostObjectStorageMutationResult>;
  /** Delete an instance and its stored credentials (2.6). */
  deleteProvider(id: string): Promise<HostObjectStorageMutationResult>;
  setCredentials(
    id: string,
    credentials: HostObjectStorageCredentialsInput
  ): Promise<HostObjectStorageMutationResult>;
  clearCredentials(id: string): Promise<HostObjectStorageMutationResult>;
  setDefaultProvider(id: string | null): Promise<HostObjectStorageMutationResult>;
}
