/** Agent-owned additions; the engine always owns the shared execution base. */
export interface HostAgentPromptSection {
  readonly id: string;
  readonly content: string;
}

export type HostAgentPromptContext =
  | { readonly id: string; readonly kind: 'text'; readonly content: string }
  | {
      readonly id: string;
      readonly kind: 'skill';
      readonly name: string;
      /** Stable source directory selected by Agent setup; exposed only to this session. */
      readonly directory?: string;
    };

export interface HostAgentPromptContribution {
  /** Session-stable identity, responsibilities and capability rules, never skill bodies. */
  readonly system?: readonly HostAgentPromptSection[];
  /** Current project/session material and catalog-backed skill reads, outside system. */
  readonly context?: readonly HostAgentPromptContext[];
}
