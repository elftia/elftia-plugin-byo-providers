import type { CreativeDocument } from './creative-document';
import type { CreativeChange, CreativeProjectSummary } from './creative-project';
import type { CreativeShot } from './creative-shot';

export interface CreativeInspectQuery {
  offset?: number;
  limit?: number;
}

export interface CreativeInspection {
  project: CreativeProjectSummary;
  documentCount: number;
  assetCount: number;
  /** Host API 1.80: shot records follow documents/assets in the bounded cursor. */
  shotCount?: number;
  shots?: CreativeShot[];
  documents: Array<{ document: CreativeDocument; status: 'available' | 'missing' | 'changed' }>;
  assets: Array<{
    id: string;
    title: string;
    kind: string;
    revision: number;
    selectedVersionId?: string;
    versionCount: number;
    selectedFileStatus?: 'available' | 'missing' | 'changed';
  }>;
  nextOffset?: number;
}

export interface CreativeChangesQuery {
  afterRevision?: number;
  offset?: number;
  limit?: number;
}

export interface CreativeChangesPage {
  projectRevision: number;
  changes: CreativeChange[];
  /** Continue with the same afterRevision and this offset. */
  nextOffset?: number;
}
