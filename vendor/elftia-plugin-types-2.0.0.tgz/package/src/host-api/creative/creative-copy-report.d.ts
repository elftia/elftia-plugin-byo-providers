/** Content migration only; archived definitions never transfer execution authorization. */
export interface CreativeProjectCopyReport {
  format: 'elftia-creative-project-copy-report/1';
  status: 'archived-needs-rebind';
  sourceProjectId: string;
  sourceRevision: number;
  sourceStateHash: string;
  newProjectId: string;
  initialStateHash: string;
  copiedAt: number;
  localContentIdsPreserved: true;
  authorizationTransferred: false;
  domains: Array<{
    domain:
      | 'project'
      | 'documents'
      | 'assets'
      | 'shots'
      | 'jobs'
      | 'batches'
      | 'batchPlans'
      | 'batchPlanResolutions'
      | 'artifactRegistrations'
      | 'authorTimelines'
      | 'compileSnapshots'
      | 'nativeAuthorBindings'
      | 'mvOperations'
      | 'productionWorkflow'
      | 'timelineBindings'
      | 'lyricsTimelineHandoffs'
      | 'changes';
    sourceCount: number;
    activeCount: number;
    status: 'preserved-content' | 'reset' | 'archived-needs-rebind';
    reason: string;
  }>;
  jobs: Array<{
    id: string;
    originalStatus: string;
    status: 'cancelled';
    action: 'archived-needs-rebind';
  }>;
  plans: Array<{
    id: string;
    nodeIds: string[];
    resolutionJobIds: string[];
    action: 'archived-needs-rebind';
  }>;
  machineTimingDocumentIds: string[];
  requiredActions: string[];
}
