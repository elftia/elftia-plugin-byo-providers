import type { CreativeCommitResult } from './creative';
import type { CreativeNativeAdoption } from './creative-native-adoption';
import type { CreativeTimelineBinding } from './creative-timeline';

/** Selectors only. Host independently verifies the registered native target and both media pins. */
export interface CreativeNativeRebind extends CreativeNativeAdoption {
  assetId: string;
  versionId: string;
}
export interface CreativeNativeRebindValue {
  assetId: string;
  versionId: string;
  sha256: string;
  bindings: CreativeTimelineBinding[];
}
export type CreativeNativeRebindRecovery =
  | { status: 'recorded'; result: CreativeCommitResult<CreativeNativeRebindValue> }
  | { status: 'not-recorded' };
/** Creator Main only. Record current native relationships; never import, place or replace media. */
export interface HostCreativeNativeRebindLike {
  readonly nativeRebindVersion?: 1;
  rebindNativeAsset?(
    input: CreativeNativeRebind
  ): Promise<CreativeCommitResult<CreativeNativeRebindValue>>;
  readNativeRebindRecovery?(input: CreativeNativeRebind): Promise<CreativeNativeRebindRecovery>;
}
