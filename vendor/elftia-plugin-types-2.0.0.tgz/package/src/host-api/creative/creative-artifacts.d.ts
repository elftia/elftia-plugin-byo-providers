import type { HostArtifactRef, HostArtifactSummary } from './creative-artifact-host';
import type { CreativeAsset, CreativeAssetInspect, CreativeAssetVersion } from './creative-asset';
import type { CreativeDocument } from './creative-document';
import type { CreativeJob } from './creative-job';
import type { CreativeSemanticRef } from './creative-semantic-board';
import type { CreativeShot } from './creative-shot';

/** Core-minted journal identity, not a generic artifact-storage locator. */
export interface CreativeArtifactRef extends HostArtifactRef {
  readonly kind: 'elftia.creative.reference';
  readonly scope: { readonly type: 'creative-project'; readonly id: string };
}

export interface CreativeArtifactRead {
  ref: CreativeArtifactRef;
}

export type CreativeArtifactSnapshotValue =
  | { kind: 'document'; document: CreativeDocument; content: string }
  | {
      kind: 'asset-version';
      asset: CreativeAsset;
      version: CreativeAssetVersion;
      availability?: CreativeAssetInspect['files'][number];
    }
  | { kind: 'shot'; shot: CreativeShot }
  | { kind: 'job'; job: CreativeJob };

/** Fixed-pin inspection; stale snapshots never substitute the latest entity. */
export interface CreativeArtifactSnapshot {
  ref: CreativeArtifactRef;
  pointer: CreativeSemanticRef;
  status: 'current' | 'stale' | 'unavailable';
  snapshot?: CreativeArtifactSnapshotValue;
  reason?: string;
}

export interface CreativeArtifactsApi {
  /** Host API 1.108. Advertise only with both real Core-backed read methods. */
  readonly version?: 1;
  getSummary(input: CreativeArtifactRead): Promise<HostArtifactSummary>;
  readSnapshot(input: CreativeArtifactRead): Promise<CreativeArtifactSnapshot>;
}
