import type { CreativeProjectCopyReport } from './creative-copy-report';

export interface CreativeProjectCopyScope {
  sourceSessionId: string;
  creativeProjectId: string;
  operationId: string;
}
export interface CreativeProjectCopyRequest extends CreativeProjectCopyScope {
  expectedRevision: number;
  /** One portable directory name, not an absolute or relative destination path. */
  destinationName: string;
  title?: string;
}
export interface CreativeProjectCopySelector extends CreativeProjectCopyScope {
  planId: string;
}
export interface CreativeProjectCopyConsume extends CreativeProjectCopySelector {
  confirmationToken: string;
}
/** Public receipt summary, never the private receipt, tree inventory or execution evidence. */
export interface CreativeProjectCopyView {
  status: 'prepared' | 'copied' | 'registered' | 'rejected' | 'needs-reconciliation';
  planId: string;
  planDigest: string;
  creativeProjectId: string;
  newProjectId: string;
  /** Host-selected paths are returned for user review, never accepted in method inputs. */
  sourceRoot: string;
  destinationRoot: string;
  expectedRevision: number;
  expiresAt: number;
  report: CreativeProjectCopyReport;
  location?: { root: string; locationRevision: number };
  residue?: string[];
  reasons?: string[];
  registrationReason?: string;
  sourceRetained: true;
}
export interface CreativeProjectCopyUnavailable {
  status: 'prepared-only' | 'cancelled';
  reason: string;
}
/** Trusted creator-only main port, optionally via fixed ext-host broker; absent in renderer and Agent catalogs.
 * Minimality: native directory selection and independent confirmation stay Host-owned.
 */
export interface HostCreativeProjectCopiesLike {
  prepareCopy(
    input: CreativeProjectCopyRequest
  ): Promise<CreativeProjectCopyView | CreativeProjectCopyUnavailable>;
  requestCopyConfirmation(input: CreativeProjectCopySelector): Promise<
    | CreativeProjectCopyUnavailable
    | {
        status: 'approved';
        confirmationToken: string;
        expiresAt: number;
      }
  >;
  executeConfirmedCopy(input: CreativeProjectCopyConsume): Promise<CreativeProjectCopyView>;
  readCopyRecovery(input: CreativeProjectCopySelector): Promise<CreativeProjectCopyView>;
  /** Revalidates a durably verified copy and retries only ID-only locator registration, never copying. */
  retryCopyRegistration(input: CreativeProjectCopySelector): Promise<CreativeProjectCopyView>;
}
