import type { CreativeMutation, CreativeProjectSummary } from './creative-project';
import type { HostCreativeLyricsTimelineLike } from './creative-lyrics-timeline';
import type { HostCreativeTimelinePlacementLike } from './creative-timeline-placement';
import type { HostCreativeTimelineReplacementLike } from './creative-timeline-replacement';
import type { HostCreativeTimelineUndoLike } from './creative-timeline-undo';
import type { HostCreativeNativeAdoptionLike } from './creative-native-adoption';
import type { HostCreativeNativeRebindLike } from './creative-native-rebind';
import type { HostCreativeImportRecoveryLike } from './creative-timeline-import-recovery';

export type * from './creative-timeline-placement';
export type * from './creative-timeline-replacement';
export type * from './creative-lyrics-timeline';
export type * from './creative-timeline-undo';
export type * from './creative-native-adoption';
export type * from './creative-native-rebind';
export type * from './creative-timeline-import-recovery';

export type RocutRevision = number;

export interface CreativeTimelineAssetRef {
  assetId: string;
  versionId: string;
  sha256: string;
}

/** Authoritative adapter readback, not a renderer cache or an edit intent. */
export interface CreativeRocutReceipt {
  receiptId: string;
  operationId: string;
  kind: 'import' | 'replace' | 'readback';
  projectId: string;
  sceneId: string;
  beforeRevision?: RocutRevision;
  revision: RocutRevision;
  assets: Array<{ externalAssetId: string; sha256: string }>;
  clips: Array<{ clipId: string; externalAssetId: string; sha256: string }>;
  observedAt: number;
}

export interface CreativeTimelineBinding extends CreativeTimelineAssetRef {
  id: string;
  projectId: string;
  sceneId: string;
  clipId?: string;
  externalAssetId: string;
  rocutRevision: RocutRevision;
  status: 'imported' | 'linked' | 'missing' | 'needs-reconciliation';
  receiptId: string;
  lastReadback?: CreativeRocutReceipt;
  createdAt: number;
  updatedAt: number;
}

export interface CreativeTimelineImport extends CreativeMutation {
  asset: CreativeTimelineAssetRef;
  receipt: CreativeRocutReceipt;
}

export interface CreativeTimelineReadback extends CreativeMutation {
  projectId: string;
  sceneId: string;
  receipt: CreativeRocutReceipt;
}

export interface CreativeTimelineReplaceRequest extends CreativeMutation {
  projectId: string;
  sceneId: string;
  clipIds: string[];
  expectedRocutRevision: RocutRevision;
  target: CreativeTimelineAssetRef;
}

/** Preparation only: Core does not edit the external project. */
export interface CreativeTimelineReplacePlan extends CreativeTimelineReplaceRequest {
  planHash: string;
  previous: Array<{
    bindingId: string;
    clipId: string;
    externalAssetId: string;
    asset: CreativeTimelineAssetRef;
  }>;
}

export interface CreativeTimelineReplace extends CreativeMutation {
  plan: CreativeTimelineReplacePlan;
  receipt: CreativeRocutReceipt;
}

export type CreativeTimelineReplaceResult =
  | { status: 'recorded'; projectRevision: number; bindings: CreativeTimelineBinding[] }
  | {
      status: 'needs-reconciliation';
      reason: string;
      plan: CreativeTimelineReplacePlan;
      receipt: CreativeRocutReceipt;
    };

export interface CreativeTimelineAuthorization extends CreativeMutation {
  targetId: string;
  projectId: string;
  sceneId: string;
}

export interface CreativeTimelineExecutionGrant {
  binding: string;
  projectRoot: string;
  targetId: string;
  projectId: string;
  sceneId: string;
  expectedRocutRevision: number;
  mediaRelativePath?: string;
  asset?: CreativeTimelineAssetRef;
  /** Fixed before native import; older Hosts may not supply durable import recovery. */
  receiptId?: string;
  /** Host-negotiated and fixed in the original private import spec; absence preserves legacy import. */
  mediaFactsVersion?: 1;
}

/** Trusted Creator main-half only. No grant or receipt method belongs to renderer API. */
export interface HostCreativeTimelinesLike
  extends
    HostCreativeTimelinePlacementLike,
    HostCreativeTimelineReplacementLike,
    HostCreativeLyricsTimelineLike,
    HostCreativeTimelineUndoLike,
    HostCreativeNativeAdoptionLike,
    HostCreativeNativeRebindLike,
    HostCreativeImportRecoveryLike {
  resolveTarget(input: {
    creativeProjectId: string;
    targetId: string;
  }): Promise<
    | { status: 'resolved'; targetId: string; projectRoot: string; nativeProjectDirectory: string }
    | { status: 'prepared'; reason: string }
  >;
  /** Discover only the already registered live editor at this authorized directory. */
  resolveWorkspaceTarget?(input: {
    creativeProjectId: string;
    nativeProjectId: string;
    nativeProjectDirectory: string;
  }): Promise<
    | { status: 'resolved'; targetId: string; projectRoot: string; nativeProjectDirectory: string }
    | { status: 'prepared'; reason: string }
  >;
  authorizeImport(
    input: CreativeTimelineAuthorization & { asset: CreativeTimelineAssetRef }
  ): Promise<CreativeTimelineExecutionGrant>;
  authorizeReadback(input: CreativeTimelineAuthorization): Promise<CreativeTimelineExecutionGrant>;
  authorizeReplace(input: {
    targetId: string;
    plan: CreativeTimelineReplacePlan;
  }): Promise<CreativeTimelineExecutionGrant>;
  recordImport(
    binding: string,
    receipt: CreativeRocutReceipt
  ): Promise<{ project: CreativeProjectSummary; value: CreativeTimelineBinding[] }>;
  recordReadback(
    binding: string,
    receipt: CreativeRocutReceipt
  ): Promise<{ project: CreativeProjectSummary; value: CreativeTimelineBinding[] }>;
  recordReplace(
    binding: string,
    receipt: CreativeRocutReceipt
  ): Promise<CreativeTimelineReplaceResult>;
}
