import type { CreativeAsset } from './creative-asset';
import type { CreativeMutation } from './creative-project';
import type { CreativeCommitResult } from './creative';
import type { CreativeTimelineBinding } from './creative-timeline';

export interface CreativeNativeDiscovery {
  creativeProjectId: string;
  sourceSessionId: string;
  targetId: string;
  projectId: string;
  sceneId: string;
}
export interface CreativeNativeCandidate {
  externalAssetId: string;
  name: string;
  kind: 'image' | 'audio' | 'video';
  clipIds: string[];
  /** Observed actual bytes, not a retained project asset or an execution grant. */
  sha256?: string;
  sizeBytes?: number;
  status: 'available' | 'unavailable';
}
export interface CreativeNativeAdoption
  extends Omit<CreativeMutation, 'sourceSessionId'>, CreativeNativeDiscovery {
  expectedNativeRevision: number;
  externalAssetId: string;
  expectedSha256: string;
}
export interface CreativeNativeAdoptionValue {
  asset: CreativeAsset;
  bindings: CreativeTimelineBinding[];
}
export type CreativeNativeAdoptionRecovery =
  | { status: 'recorded'; result: CreativeCommitResult<CreativeNativeAdoptionValue> }
  | { status: 'not-recorded' };
/** Creator main only. Host reads private native evidence itself; no supplied paths/receipts. */
export interface HostCreativeNativeAdoptionLike {
  discoverNativeAssets?(
    input: CreativeNativeDiscovery
  ): Promise<
    | { status: 'available'; revision: number; candidates: CreativeNativeCandidate[] }
    | { status: 'prepared'; reason: string }
  >;
  adoptNativeAsset?(
    input: CreativeNativeAdoption
  ): Promise<CreativeCommitResult<CreativeNativeAdoptionValue>>;
  readNativeAdoptionRecovery?(
    input: CreativeNativeAdoption
  ): Promise<CreativeNativeAdoptionRecovery>;
}
