import type { CreativeMvScope } from './creative-mv';

export type CreativeMvMaterialInput = CreativeMvScope & {
  target: {
    timelineId?: string;
    nodeId?: string;
    shotId?: string;
    shotTitle?: string;
    purpose?: 'media' | 'background' | 'character';
  };
  candidate?: { requestId?: string; index?: number };
  processing?: { chromaKey?: [number, number, number]; tolerance?: number };
  replaceScope?: 'target' | 'shared-pin';
  applyNative?: boolean;
};
export type CreativeMvMaterialTakeInput = Omit<CreativeMvMaterialInput, 'candidate'> & {
  requestId?: string;
  take: string;
  execution?: 'plan' | 'run-and-prepare';
  candidateIndex?: number;
  changes: {
    prompt?: string;
    providerId?: string;
    modelId?: string;
    referenceRequestId?: string;
    referenceImages?: Array<{ assetId: string; versionId: string }>;
    aspectRatio?: string;
    resolution?: string;
  };
};
