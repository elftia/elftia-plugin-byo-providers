/** Historical project-local output intent, not provider input or assignment/approval authority. */
export interface CreativeGenerationDestinationContext {
  /** Explicit tags initialize new assets only; existing asset metadata is unchanged. */
  tags?: string[];
  documents?: Array<{
    purpose: 'character' | 'scene';
    documentId: string;
    revision: number;
    contentHash: string;
  }>;
  shot?: { shotId: string; revision: number; slot: string };
}
