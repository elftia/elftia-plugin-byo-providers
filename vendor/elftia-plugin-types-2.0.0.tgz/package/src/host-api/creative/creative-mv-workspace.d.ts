export interface CreativeMvWorkspace {
  creativeProjectId: string;
  revision: number;
  preparation?: {
    status: string;
    durationSeconds?: number;
    frameRate?: { numerator: number; denominator: number };
  };
  operations?: Array<{
    operationId: string;
    intent: string;
    status: string;
    reason?: string;
    jobs: Array<{ id: string; status: string; stage: string; reason?: string }>;
  }>;
  materials?: Array<{
    requestId: string;
    title: string;
    purpose: string;
    status: string;
    taskKey?: string;
    imageKey?: string;
    selectedPin?: { assetId: string; versionId: string; sha256: string };
    candidates: Array<{ assetId: string; versionId: string }>;
    authorNodeIds: string[];
    nativeBindingIds: string[];
    targets: Array<{
      timelineId: string;
      nodeId: string;
      purpose: 'media' | 'background' | 'character';
      title: string;
    }>;
  }>;
  timelines: Array<{
    id: string;
    revision: number;
    contentHash: string;
    nodeCount: number;
    range: { startTick: number; endTick: number };
    ticksPerSecond: number;
    ticksPerFrame?: number;
    appliedSnapshotId?: string;
    nativeLocation?: { projectPath: string; nativeProjectId: string; sceneId: string };
    shots: Array<{
      id: string;
      title: string;
      nodeCount: number;
      startTick?: number;
      endTick?: number;
      nativeObjectIds?: string[];
      nativeStartTick?: number;
    }>;
  }>;
  deliveries: Array<{
    operationId: string;
    timelineId?: string;
    jobId: string;
    status: string;
    stage: string;
    cancelRequested: boolean;
    reason?: string;
    candidates: Array<{ assetId: string; versionId: string }>;
    segments?: { completed: number; total: number };
    delivery?: {
      snapshotId: string;
      author: { relativePath: string; sha256: string };
      compiled: { relativePath: string; sha256: string };
      editable: {
        relativePath: string;
        manifestSha256: string;
        sourceDigest: string;
        revision: number;
      };
    };
  }>;
}
