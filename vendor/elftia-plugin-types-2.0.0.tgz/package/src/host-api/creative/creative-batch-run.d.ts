export type CreativeBatchRunNodeState =
  | 'waiting'
  | 'claimed'
  | 'reserved'
  | 'completed'
  | 'failed'
  | 'blocked'
  | 'needs-reconciliation';

export interface CreativeBatchRunNode {
  nodeId: string;
  jobId?: string;
  requestHash?: string;
  state: CreativeBatchRunNodeState;
  externalRunHandle?: string;
  reason?: string;
}

export interface CreativeBatchRun {
  runId: string;
  revision: number;
  creativeProjectId: string;
  planId: string;
  planHash: string;
  sourceSessionId: string;
  startOperationId: string;
  maxConcurrency: number;
  mode: 'active' | 'paused';
  createdAt: number;
  updatedAt: number;
  nodes: CreativeBatchRunNode[];
}

export interface CreativeBatchRunStart {
  creativeProjectId: string;
  planId: string;
  expectedPlanHash: string;
  expectedRevision: number;
  operationId: string;
  sourceSessionId: string;
  maxConcurrency: number;
}
export interface CreativeBatchRunTarget {
  creativeProjectId: string;
  runId: string;
}
export interface CreativeBatchRunMutation extends CreativeBatchRunTarget {
  expectedRunRevision: number;
  operationId: string;
}
export type CreativeBatchRunExecutor = (
  target: { creativeProjectId: string; jobId: string },
  action: 'execute' | 'resume'
) => Promise<unknown>;

/** Main-only; callback results never constitute a producer completion proof. */
export interface HostCreativeBatchRunsLike {
  start(input: CreativeBatchRunStart): Promise<CreativeBatchRun>;
  get(input: CreativeBatchRunTarget): Promise<CreativeBatchRun>;
  list(input: { creativeProjectId: string; planId?: string }): Promise<CreativeBatchRun[]>;
  pause(input: CreativeBatchRunMutation): Promise<CreativeBatchRun>;
  resume(input: CreativeBatchRunMutation): Promise<CreativeBatchRun>;
  attachExecutor(callback: CreativeBatchRunExecutor): () => void;
}
