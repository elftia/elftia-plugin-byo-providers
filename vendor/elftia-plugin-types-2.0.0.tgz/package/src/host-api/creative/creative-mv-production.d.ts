import type { CreativeMvScope } from './creative-mv';

export type CreativeMvProductionInput = CreativeMvScope & {
  key: string;
  action?: 'start' | 'observe' | 'resume' | 'select';
  images?: Array<{
    key: string;
    shotTitle: string;
    purpose: string;
    prompt: string;
    providerId: string;
    modelId?: string;
    title?: string;
    aspectRatio?: string;
    resolution?: string;
    referenceKey?: string;
  }>;
  imageKey?: string;
  candidateIndex?: number;
};
export interface CreativeMvProductionResult {
  operationId: string;
  key: string;
  status: string;
  images: Array<{
    key: string;
    requestId: string;
    status: string;
    candidates: Array<{ assetId: string; versionId: string }>;
    selectedPin?: { assetId: string; versionId: string; sha256: string };
  }>;
}
