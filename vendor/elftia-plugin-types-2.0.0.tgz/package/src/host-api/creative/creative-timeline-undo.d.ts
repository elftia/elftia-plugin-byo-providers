/** Undo one verified Host operation, not the editor's general command history. */
export interface CreativeTimelineUndoInput {
  creativeProjectId: string;
  sourceSessionId: string;
  originalOperationId: string;
  operationId: string;
  expectedRevision: number;
  kind: 'placement' | 'replacement';
}

export interface CreativeTimelineUndoPreview {
  planId: string;
  executionHash: string;
  originalOperationId: string;
  operationId: string;
  kind: 'placement' | 'replacement';
  projectId: string;
  sceneId: string;
  expectedNativeRevision: number;
  clipIds: string[];
}

export interface CreativeTimelineUndoRecoveryInput {
  creativeProjectId: string;
  sourceSessionId: string;
  operationId: string;
}

/** Creator main-half only; approvals are issued by an independent trusted Host UI. */
export interface HostCreativeTimelineUndoLike {
  prepareUndo?(
    input: CreativeTimelineUndoInput
  ): Promise<
    | { status: 'prepared'; plan: CreativeTimelineUndoPreview }
    | { status: 'prepared-only'; reason: string }
  >;
  requestUndoConfirmation?(input: {
    planId: string;
  }): Promise<
    | { status: 'approved'; confirmationToken: string; expiresAt: number }
    | { status: 'cancelled' | 'prepared-only'; reason: string }
  >;
  executeConfirmedUndo?(input: {
    planId: string;
    confirmationToken: string;
  }): Promise<
    | { status: 'recorded'; intentId: string; projectRevision: number }
    | { status: 'needs-reconciliation'; intentId: string; reason: string }
  >;
  readUndoRecovery?(input: CreativeTimelineUndoRecoveryInput): Promise<{
    status: 'recorded' | 'needs-reconciliation';
    intentId: string;
    artifactMatch: boolean;
    projectRevision?: number;
    reason: string;
  }>;
}
