/** Observations of fixed source bytes, not generation settings or decoded-media QA. */
export interface CreativeMediaFacts {
  schemaVersion: 1;
  source: 'byte-probe';
  sha256: string;
  frameRate?: {
    numerator: number;
    denominator: number;
    /** Constant/variable require complete observations; average is not an exact CFR claim. */
    mode: 'constant' | 'variable' | 'average';
    samples: number;
    complete: boolean;
  };
  /** Encoded alpha-channel presence, not a claim that a pixel is transparent. */
  alpha?: boolean;
  /** Fully inspected image containers. Loop zero means infinite; duration uses 120000 ticks/second. */
  animation?: { frameCount: number; loopCount?: number; durationTicks?: number };
  /** Channel layout is never inferred from channel count. */
  audio?: { channels: number; sampleRate: number; layout?: string };
}
