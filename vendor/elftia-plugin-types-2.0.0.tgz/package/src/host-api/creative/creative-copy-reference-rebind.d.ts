export interface CreativeCopyReferencePage<T> {
  total: number;
  items: T[];
  truncated: boolean;
}
export interface CreativeCopyBoardReference {
  sourceBoardId: string;
  title: string;
  detachedElementIds: string[];
  detachedElementCount: number;
  detachedFileIds: string[];
  detachedFileCount: number;
  /** The individual detached ID lists may also be bounded. */
  truncated: boolean;
}
export type CreativeCopyReferencePinStatus =
  | 'available'
  | 'missing-asset'
  | 'missing-version'
  | 'fingerprint-mismatch'
  | 'unavailable';
export interface CreativeCopyNativeReference {
  sourceBindingId: string;
  /** Historical identifiers, never an authorized current native target. */
  projectId: string;
  sceneId: string;
  externalAssetId: string;
  clipId?: string;
  assetId: string;
  versionId: string;
  sha256: string;
  currentPinStatus: CreativeCopyReferencePinStatus;
}
/** Inert metadata only. Actions require fresh explicit current selections and Host authorization. */
export interface CreativeCopyReferenceRebindCatalog {
  version: 1;
  historicalOnly: true;
  authorizationTransferred: false;
  boards: CreativeCopyReferencePage<CreativeCopyBoardReference>;
  nativeBindings: CreativeCopyReferencePage<CreativeCopyNativeReference>;
}
