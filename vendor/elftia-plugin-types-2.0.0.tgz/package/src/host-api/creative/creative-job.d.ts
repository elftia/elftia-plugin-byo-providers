import type { CreativeMutation } from './creative-project';

export type CreativeProducer = 'generation' | 'analysis' | 'director' | 'programmatic';
export type CreativeJobStatus =
  | 'queued'
  | 'running'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'needs-reconciliation';

export interface CreativeJobAssetRef {
  assetId: string;
  versionId: string;
}

export interface CreativeJobExecutionReceipt {
  externalRunHandle: string;
  runRelativePath: string;
  locationRevision: number;
  command: 'analyze' | 'separate' | 'align';
  inputFingerprints: Record<string, { relativePath: string; sha256: string; bytes: number }>;
  toolkitFingerprints: Record<string, string>;
  parameters: Record<string, unknown>;
  claimedAt: number;
}

export interface CreativeJob {
  id: string;
  producer: CreativeProducer;
  status: CreativeJobStatus;
  stage: string;
  inputs: CreativeJobAssetRef[];
  recipe: Record<string, unknown>;
  requestHash: string;
  externalRunHandle?: string;
  execution?: CreativeJobExecutionReceipt;
  candidates: CreativeJobAssetRef[];
  cancelRequestedAt?: number;
  lastObservationId?: string;
  lastError?: { code: string; message: string };
  sourceSessionId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface CreativeJobRequest extends CreativeMutation {
  producer: CreativeProducer;
  inputs: CreativeJobAssetRef[];
  recipe: Record<string, unknown>;
}

export interface CreativeJobCancelRequest extends CreativeMutation {
  jobId: string;
}
