export type MvTemplateJson =
  | null
  | boolean
  | number
  | string
  | MvTemplateJson[]
  | { [key: string]: MvTemplateJson };
export interface HostMvRecipeResource {
  id: string;
  kind: 'image' | 'analysis' | 'font';
  mimeType: string;
  attachmentKey: string;
  byteLength: number;
  sha256: string;
  font?: { family: string; style: 'normal' | 'italic'; weight: number };
}
export interface HostMvSceneBuildRequest {
  templateId: 'creator-studio.handdrawn-shot';
  templateVersion: 1;
  helperFingerprint: string;
  frameRate: { numerator: number; denominator: number };
  startTick: number;
  endTick: number;
  seed: number;
  bpm: number;
  actor: {
    /** Omission keeps the character behind lyrics; author plans materialize this choice. */
    layer?: 'behind-lyrics' | 'in-front-of-lyrics';
    /** Pixel coordinates of the bottom-center anchor; h extends upward, sway uses radians. */
    x: number;
    y: number;
    h: number;
    sway?: number;
    breathe?: number;
    wave?: { amp: number; from: number; freq: number; speed: number; drawingFps: number };
  };
  background: HostMvRecipeResource;
  character: HostMvRecipeResource;
  analysis: HostMvRecipeResource;
  sourceAudioSha256: string;
}
export interface HostMvRecipeSource {
  version: 1;
  runtime: 'canvas-worker';
  code: '';
  width: number;
  height: number;
  frameRate: { numerator: number; denominator: number };
  durationFrames: number;
  seed: number;
  resources: HostMvRecipeResource[];
  recipe: Record<string, MvTemplateJson>;
}
export interface HostMvSceneBuildResult {
  helperFingerprint: string;
  startTime: number;
  duration: number;
  sources: { back: HostMvRecipeSource; front: HostMvRecipeSource };
}
export type HostMvTemplateContribution =
  | {
      id: string;
      version: number;
      kind: 'lyrics-jizura';
      starterPreset: 'clean-caption' | 'impact-title' | 'editorial-paper' | 'mono-marquee';
      language: string;
      seed: number;
    }
  | {
      id: string;
      version: number;
      kind: 'lyrics-line';
      /** fontSize uses reference pixels at 1080 canvas height, never native parameter units. */
      text: { fontFamily: string; fontSize: number; color: string };
    }
  | {
      id: 'creator-studio.handdrawn-shot';
      version: 1;
      kind: 'handdrawn-shot';
      helperFingerprint: string;
      outputRoles: ['background', 'foreground'];
    };
/** Owner-scoped data and a finite recipe helper. No paths, editor state or arbitrary code cross this port. */
export interface HostCreativeMvTemplates {
  register(input: {
    contributions: readonly HostMvTemplateContribution[];
    buildScene(input: HostMvSceneBuildRequest): Promise<HostMvSceneBuildResult>;
  }): () => void;
}
