import type { CreativeJob } from './creative-job';
import type { CreativeGenerationDestinationContext } from './creative-generation-context';
import type { CreativeMutation } from './creative-project';

export type CreativeBatchPlanMediaKind = 'image' | 'video' | 'audio' | 'other' | 'model';
export type CreativeBatchPlanInput =
  | {
      kind: 'fixed';
      assetId: string;
      versionId: string;
      sha256: string;
      mediaKind: CreativeBatchPlanMediaKind;
    }
  | {
      kind: 'future-output';
      upstreamNodeId: string;
      expectedUpstreamHash: string;
      mediaKind: CreativeBatchPlanMediaKind;
      outputName?: string;
    };
export type CreativeBatchPlanTemplate =
  | {
      producer: 'generation';
      recipe: {
        config: Record<string, unknown>;
        outputAssetId?: string;
        destinationContext?: CreativeGenerationDestinationContext;
      };
      bindings: Record<string, CreativeBatchPlanInput | CreativeBatchPlanInput[]>;
    }
  | {
      producer: 'analysis';
      recipe: { command: 'analyze' | 'separate' | 'align'; parameters: Record<string, unknown> };
      bindings: Record<string, CreativeBatchPlanInput>;
    };
export type CreativeBatchPlanNode =
  | { kind: 'existing-job'; nodeId: string; jobId: string; requestHash: string }
  | {
      kind: 'deferred-template';
      nodeId: string;
      template: CreativeBatchPlanTemplate;
      templateHash: string;
    };
export interface CreativeBatchPlanEdge {
  prerequisiteNodeId: string;
  dependentNodeId: string;
}
export interface CreativeBatchPlan {
  id: string;
  title: string;
  planHash: string;
  nodes: CreativeBatchPlanNode[];
  edges: CreativeBatchPlanEdge[];
  createdAt: number;
  sourceSessionId: string;
  creationOperationId: string;
}
export interface CreativeBatchPlanCreate extends CreativeMutation {
  sourceSessionId: string;
  title: string;
  nodes: Array<
    | Extract<CreativeBatchPlanNode, { kind: 'existing-job' }>
    | Omit<Extract<CreativeBatchPlanNode, { kind: 'deferred-template' }>, 'templateHash'>
  >;
  edges: CreativeBatchPlanEdge[];
}
export interface CreativeBatchPlanRef {
  creativeProjectId: string;
  sourceSessionId?: string;
  planId: string;
}
export interface CreativeBatchPlanMaterialize extends CreativeMutation {
  sourceSessionId: string;
  planId: string;
  nodeId: string;
  expectedPlanHash: string;
  expectedTemplateHash: string;
}
export interface CreativeBatchPlanResolvedBinding {
  slot: string;
  position: number;
  assetId: string;
  versionId: string;
  sha256: string;
  bytes: number;
  mediaKind: CreativeBatchPlanMediaKind;
  upstream?: {
    nodeId: string;
    jobId: string;
    requestHash: string;
    externalRunHandle: string;
    sourceSessionId: string;
  };
}
export interface CreativeBatchPlanResolution {
  planId: string;
  nodeId: string;
  planHash: string;
  templateHash: string;
  jobId: string;
  requestHash: string;
  bindings: CreativeBatchPlanResolvedBinding[];
  operationId: string;
  sourceSessionId: string;
  createdAt: number;
}
export interface CreativeBatchPlanReadiness {
  plan: CreativeBatchPlan;
  projectRevision: number;
  resolutions: CreativeBatchPlanResolution[];
  nodes: Array<{
    nodeId: string;
    jobId?: string;
    state: 'ready' | 'blocked' | 'materialized' | 'reserved' | 'terminal';
    blockers: Array<{ nodeId: string; reason: string }>;
  }>;
}
export interface CreativeBatchPlanMaterialized {
  resolution: CreativeBatchPlanResolution;
  job: CreativeJob;
}
