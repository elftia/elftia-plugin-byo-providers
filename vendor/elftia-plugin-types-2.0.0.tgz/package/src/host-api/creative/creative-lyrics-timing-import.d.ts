import type { CreativeMutation } from './creative-project';
import type { CreativeLyricsTimingAudio, CreativeLyricsTimingRef } from './creative-lyrics-timing';

export interface CreativeLyricsTimingAnalysisPin {
  jobId: string;
  requestHash: string;
  assetId: string;
  versionId: string;
  sha256: string;
}
export interface CreativeLyricsTimingSuggestion {
  lineId: string;
  index: number;
  textHash: string;
  startSeconds: number;
  endSeconds: number;
  review: 'required';
}
export interface CreativeLyricsTimingMachine {
  schema: 'elftia-lyrics-analysis-import/1';
  analysis: CreativeLyricsTimingAnalysisPin;
  receiptSha256: string;
  manifestSha256: string;
  lyricsSha256: string;
  vocals: CreativeLyricsTimingAudio;
  mapping: {
    kind: 'direct-input' | 'zero-offset-separation';
    sourceAudio: CreativeLyricsTimingAudio;
    offsetSeconds: 0;
    separation?: {
      analysis: CreativeLyricsTimingAnalysisPin;
      receiptSha256: string;
      manifestSha256: string;
      stemsSha256: string;
    };
  };
  suggestions: CreativeLyricsTimingSuggestion[];
}
export interface CreativeLyricsTimingImportPreviewInput extends CreativeLyricsTimingRef {
  expectedDocumentRevision: number;
  expectedContentHash: string;
  analysis: CreativeLyricsTimingAnalysisPin;
}
export interface CreativeLyricsTimingImportPreview {
  status: 'ready' | 'unavailable';
  reasons: string[];
  previewHash: string;
  documentId: string;
  documentRevision: number;
  contentHash: string;
  machine?: CreativeLyricsTimingMachine;
  rangeVerification: 'unverified';
}
export interface CreativeLyricsTimingImport extends CreativeMutation {
  documentId: string;
  expectedDocumentRevision: number;
  expectedContentHash: string;
  analysis: CreativeLyricsTimingAnalysisPin;
  expectedPreviewHash: string;
}
