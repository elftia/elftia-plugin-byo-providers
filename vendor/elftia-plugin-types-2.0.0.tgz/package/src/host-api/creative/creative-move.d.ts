import type {
  CreativeProjectCopyConsume,
  CreativeProjectCopySelector,
  CreativeProjectCopyUnavailable,
  CreativeProjectCopyRequest,
} from './creative-copy';

/** Public move receipt summary; never private tree inventories or runtime executors. */
export interface CreativeProjectMoveView {
  planId: string;
  digest: string;
  id: string;
  sourceRoot: string;
  destinationRoot: string;
  revision: number;
  expiresAt: number;
  status: string;
  writeFence: 'none' | 'held' | 'released' | 'unknown';
  reason?: string;
  runtimeReleased?: boolean;
}
/** Optional Creator main-only service. Paths and approval tokens are Host-owned. */
export interface HostCreativeProjectMovesLike {
  prepareMove(
    input: Omit<CreativeProjectCopyRequest, 'title'>
  ): Promise<CreativeProjectMoveView | CreativeProjectCopyUnavailable>;
  requestMoveConfirmation(
    input: CreativeProjectCopySelector
  ): Promise<
    | CreativeProjectCopyUnavailable
    | { status: 'approved'; confirmationToken: string; expiresAt: number }
  >;
  executeConfirmedMove(input: CreativeProjectCopyConsume): Promise<CreativeProjectMoveView>;
  readMoveRecovery(input: CreativeProjectCopySelector): Promise<CreativeProjectMoveView>;
  /** Trusted confirmation and record-only recovery; never starts a fresh copy. */
  recoverCommittedMove(
    input: CreativeProjectCopySelector
  ): Promise<CreativeProjectMoveView | CreativeProjectCopyUnavailable>;
}
