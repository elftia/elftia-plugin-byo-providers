/** Pure data declaration seam for ../artifacts.ts; keep structurally identical. */
export interface HostArtifactRef {
  readonly protocol: 'elftia.artifact/v1';
  readonly kind: string;
  readonly artifactId: string;
  readonly scope:
    | { readonly type: 'creative-project'; readonly id: string }
    | { readonly type: 'project'; readonly id: string }
    | { readonly type: 'session'; readonly id: string }
    | { readonly type: 'library'; readonly id: string };
}

export interface HostArtifactSummary {
  readonly ref: HostArtifactRef;
  readonly revision: number;
  readonly title: string;
  readonly subtitle?: string;
  readonly thumbnailUrl?: string;
  readonly durationTicks?: number;
  readonly state:
    | 'ready'
    | 'busy'
    | 'error'
    | 'provider-missing'
    | 'tombstoned'
    | 'migration-required';
  readonly badges?: readonly {
    readonly id: string;
    readonly label: string;
    readonly tone?: 'neutral' | 'info' | 'warning' | 'danger';
  }[];
}
