import type {
  CreativeJob,
  CreativeJobCancelRequest,
  CreativeJobExecutionReceipt,
  CreativeJobAssetRef,
} from './creative-job';

export interface CreativeAnalysisGrant {
  status: 'authorized';
  jobId: string;
  creativeProjectId: string;
  projectRoot: string;
  locationRevision: number;
  job: CreativeJob;
  command: 'analyze' | 'separate' | 'align';
  inputs: CreativeJobExecutionReceipt['inputFingerprints'];
  parameters: Record<string, unknown>;
}

export interface CreativeAnalysisObservation {
  observationId: string;
  externalRunHandle: string;
  status: Exclude<CreativeJob['status'], 'queued'>;
  stage: string;
  candidates?: CreativeJobAssetRef[];
  lastError?: { code: string; message: string };
}

/** Trusted Creator backend capability. Never expose bindings or grants to renderer code. */
export interface HostCreativeAnalysisLike {
  bind(input: {
    creativeProjectId: string;
    jobId: string;
    action: 'execute' | 'resume';
  }): Promise<{ binding: string }>;
  authorize(
    binding: string
  ): Promise<CreativeAnalysisGrant | { status: 'prepared'; reason: string }>;
  receipt(binding: string): Promise<CreativeJobExecutionReceipt | null>;
  claim(binding: string, receipt: CreativeJobExecutionReceipt): Promise<void>;
  /** Original trusted execute binding only; never issued from a project manifest. */
  attestExit?(
    binding: string,
    input: {
      externalRunHandle: string;
      manifestSha256: string;
      exited: true;
      exitCode: 0;
      signal: null;
    }
  ): Promise<{ verified: boolean }>;
  /** Host-private readback for recovery; does not launch or create evidence. */
  verifyExit?(
    binding: string,
    input: { externalRunHandle: string; manifestSha256: string }
  ): Promise<{ verified: boolean }>;
  observe(binding: string, observation: CreativeAnalysisObservation): Promise<unknown>;
  archiveCandidate(
    binding: string,
    output: {
      name: string;
      relativePath: string;
      sha256: string;
      bytes: number;
      kind: 'audio' | 'other';
    },
    run: { manifestSha256: string }
  ): Promise<CreativeJobAssetRef>;
  cancelRequest(input: CreativeJobCancelRequest): Promise<unknown>;
}
