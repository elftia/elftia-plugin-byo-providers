import type {
  CreativeMvNativeSyncInput,
  CreativeMvNativeSyncResult,
} from './creative-mv-native-sync';
import type {
  CreativeMvProductionInput,
  CreativeMvProductionResult,
} from './creative-mv-production';
import type { CreativeMvMaterialInput, CreativeMvMaterialTakeInput } from './creative-mv-materials';

export interface CreativeMvScope {
  creativeProjectId: string;
  sourceSessionId: string;
}
export type CreativeMvSelection =
  | { type: 'all' }
  | { type: 'shots'; shotIds: string[] }
  | { type: 'range'; range: { startTick: number; endTick: number } };
export interface CreativeMvTaskResult {
  status: string;
  operationId?: string;
  jobId?: string;
  segmentJobIds?: string[];
  activeJobId?: string;
  snapshotId?: string;
  reason?: string;
  diagnostics?: Array<{ code: string; message: string; nodeId?: string }>;
  candidates?: Array<{ assetId: string; versionId: string }>;
  requestedSongSeconds?: number;
  actualSongSeconds?: number;
  image?: { assetId: string; versionId: string; sha256: string; relativePath: string };
}
import type { CreativeMvWorkspace } from './creative-mv-workspace';
export type { CreativeMvWorkspace } from './creative-mv-workspace';
/** Task-level MV UI uses the same Core services as the scoped toolkit. */
export interface CreativeMvApi {
  /** Renderer-only view intent; resolves the saved shot mapping without editing project content. */
  locate?(
    input: CreativeMvScope & { timelineId: string; shotId: string }
  ): Promise<CreativeMvTaskResult>;
  prepareMaterial(input: CreativeMvMaterialInput): Promise<CreativeMvTaskResult>;
  reviseMaterial(input: CreativeMvMaterialTakeInput): Promise<CreativeMvTaskResult>;
  nativeSync(input: CreativeMvNativeSyncInput): Promise<CreativeMvNativeSyncResult>;
  taskControl(
    input: CreativeMvScope & {
      operationId: string;
      action?: 'observe' | 'resume' | 'pause' | 'cancel';
    }
  ): Promise<CreativeMvTaskResult>;
  productionTask(input: CreativeMvProductionInput): Promise<CreativeMvProductionResult>;
  preview(
    input: CreativeMvScope & { timelineId: string; atSeconds: number }
  ): Promise<CreativeMvTaskResult>;
  workspace(input: CreativeMvScope): Promise<CreativeMvWorkspace>;
  apply(
    input: CreativeMvScope & { timelineId: string; selection?: CreativeMvSelection }
  ): Promise<CreativeMvTaskResult>;
  render(
    input: CreativeMvScope & {
      timelineId: string;
      selection?: CreativeMvSelection;
      options?: {
        format?: 'mp4' | 'webm';
        quality?: 'low' | 'medium' | 'high' | 'very_high';
        includeAudio?: boolean;
      };
    }
  ): Promise<CreativeMvTaskResult>;
  deliveryOperation(
    input: CreativeMvScope & {
      operationId: string;
      action?: 'observe' | 'resume' | 'pause' | 'cancel';
    }
  ): Promise<CreativeMvTaskResult>;
}
