import type { CreativeJob, CreativeJobAssetRef, CreativeJobCancelRequest } from './creative-job';

export interface CreativeGenerationTarget {
  creativeProjectId: string;
  jobId: string;
}
export interface CreativeGenerationResult {
  status: CreativeJob['status'] | 'prepared';
  reason?: string;
  externalRunHandle?: string;
  candidates?: CreativeJobAssetRef[];
  cancelRequestedAt?: number;
}
/** Main-only execution port; recipes, roots and provider attachments are Host-owned. */
export interface HostCreativeGenerationLike {
  /** Supports validated historical destination intent without provider or assignment authority. */
  readonly destinationContextVersion?: 1;
  execute(input: CreativeGenerationTarget): Promise<CreativeGenerationResult>;
  resume(input: CreativeGenerationTarget): Promise<CreativeGenerationResult>;
  cancelRequest(input: CreativeJobCancelRequest): Promise<CreativeGenerationResult>;
}
