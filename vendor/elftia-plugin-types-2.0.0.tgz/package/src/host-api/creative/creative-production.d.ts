import type { CreativeJobAssetRef, CreativeJobStatus } from './creative-job';
import type {
  CreativePrepareComposition,
  CreativePrepareCompositionResult,
} from './creative-composition-production';
export type * from './creative-composition-production';

export interface CreativeProductionTarget {
  creativeProjectId: string;
  jobId: string;
}
export interface CreativeProductionResult {
  status: CreativeJobStatus | 'prepared';
  reason?: string;
  externalRunHandle?: string;
  candidates?: CreativeJobAssetRef[];
}
export interface CreativeRocutExportOptions {
  format: 'mp4' | 'webm';
  quality: 'low' | 'medium' | 'high' | 'very_high';
  includeAudio?: boolean;
  videoChroma?: '420' | '444';
  videoQuantizer?: number;
  /** Native integer media ticks, not seconds. */
  range?: { startTime: number; endTime: number };
}
export interface CreativeRocutProductionPlanTarget {
  creativeProjectId: string;
  /** Trusted Host/bindSession attribution; never supplied by the model. */
  sourceSessionId: string;
  targetId: string;
  nativeProjectId: string;
  expectedNativeRevision: number;
  options: CreativeRocutExportOptions;
}
export interface CreativeRocutProductionRecipe {
  schema: 'elftia-rocut-production/1';
  scope: 'native-project';
  targetId: string;
  nativeProjectId: string;
  expectedNativeRevision: number;
  expectedSourceDigest: string;
  options: CreativeRocutExportOptions;
  outputAssetId?: string;
}
export type CreativeRocutProductionPlanResult =
  | {
      status: 'planned';
      recipe: CreativeRocutProductionRecipe;
      sourceRevision: number;
      sourceDigest: string;
      /** Belongs to this read-only query, not a subsequent production job. */
      queryRequestHash: string;
    }
  | { status: 'unavailable'; reason: string };
/** Main-only native production. Connections, source snapshots and bytes remain Host-owned. */
export interface HostCreativeProductionLike {
  execute(input: CreativeProductionTarget): Promise<CreativeProductionResult>;
  /** Observes the admitted request without starting a second native render. */
  resume(input: CreativeProductionTarget): Promise<CreativeProductionResult>;
  /** Host API 1.83: read-only native admission; no job, reservation or dispatch. */
  planRocut?(input: CreativeRocutProductionPlanTarget): Promise<CreativeRocutProductionPlanResult>;
  /** Host API 1.88: explicit source archival, without compilation, render dispatch or job creation. */
  prepareComposition?(input: CreativePrepareComposition): Promise<CreativePrepareCompositionResult>;
}
