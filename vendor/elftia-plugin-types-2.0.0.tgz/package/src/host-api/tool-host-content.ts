import type { HostUnregister } from './_shared';

/** The embedding host supplies scope; the embedded document cannot choose it. */
export interface ToolHostContentRequest {
  readonly sessionId: string;
  readonly projectPath: string;
  readonly method: 'snapshot' | 'execute';
  readonly command?: unknown;
  /** Explicit opt-in; older hosts omit this field. */
  readonly transport?: { readonly version: 1; readonly knownRevision?: string };
}

export interface ToolHostContentRegistration {
  readonly toolId: string;
  readonly handle: (request: ToolHostContentRequest) => Promise<unknown>;
}

/** Data-only integration for an admitted tool surface; does not expose IPC or credentials. */
export interface HostToolHostContent {
  register(registration: ToolHostContentRegistration): HostUnregister;
}
