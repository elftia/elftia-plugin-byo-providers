/**
 * host-api/media-storage.ts — `HostMediaStorageLike`, the
 * `host.services.mediaStorage` capability port (`canvas-host-adapter-ports`
 * T0a, host-API v1.59; owner ruling O13).
 *
 * The three core media-storage primitives — `save` / `readAsBase64` /
 * `resolveMediaUrl` — over the SAME `MediaStorageService` singleton that mints
 * `media://` references for the media tools bridge. Lets a canvas-side
 * consumer (the S09 `elftia-canvas` toolkit, a future canvas plugin) persist
 * generated/imported media and resolve references WITHOUT importing the
 * `@main` service class — the second execution path the T7 import gate
 * exists to forbid.
 *
 * ── MASK-ON-RETURN (owner ruling O13, the security crux) ──
 * EVERY result `save` returns carries ONLY opaque media references
 * (`assetId`, the `media://` `fileUrl`, thumbnail URLs/base64, `mimeType`).
 * The four filesystem-path members of the canonical `SaveMediaResult` —
 * `filePath` (a userData-relative tail in-root, else an ABSOLUTE path),
 * `absoluteFilePath`, `thumbnailPath`, `mediumThumbnailPath` — are typed
 * `?: never` here, so a returned value that carried a populated path member
 * would FAIL to type-check (a forgotten adapter strip is a compile error,
 * not a silent local-path leak). The mask is enforced TWICE, the
 * `mediaConfigHostAdapter` discipline: (a) STRUCTURALLY here, and (b) at the
 * adapter boundary (a `toPluginMediaStorageResult` destructuring-strip on
 * every return — the runtime half, which also covers a future path-bearing
 * field the closed type cannot pin). `readAsBase64` / `resolveMediaUrl`
 * return the payload / ref themselves (the consumption target); no path
 * member rides them.
 *
 * ── WHAT IS DELIBERATELY NOT HERE ──
 * The image-only attachment transforms (`processNewAttachments` /
 * `attachmentsToBase64` / `preprocessRegenAttachments`) do NOT cross: core
 * marks them host-specific projections (`ports/media-generation.ts`), and
 * O13 scopes this port to the three storage primitives.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports
 * it. The payload shapes are STRUCTURAL LOWER BOUNDS (no `@main`/`@shared`
 * import): the host's canonical `SaveMediaInput` is structurally assignable,
 * and the plugin re-narrows what it reads.
 *
 * @module @elftia/plugin-types/host-api/media-storage
 */

/**
 * `save` input — a structural lower bound of the canonical `SaveMediaInput`
 * (`MediaStorageService.save`). `sessionId` stays a RAW session id (the
 * storage layout key): O13 scoped the opaque-handle ruling to the
 * `canvasScene` port only; the host-side toolkit (S09 child 2) is the surface
 * that must source the id from its host-injected context, never from model
 * arguments.
 */
export interface HostMediaStorageSaveInput {
  /** Owning chat session id (the storage layout key: `media/<sessionId>/…`). */
  readonly sessionId: string;
  /** Owning message id (the storage layout key: `…/<messageId>/…`). */
  readonly messageId: string;
  /** The media bytes, base64-encoded (INWARD only; never echoed). */
  readonly base64: string;
  /** The media MIME type (`image/png`, …). */
  readonly mimeType: string;
  /** Pre-minted asset id (a fresh UUID is minted when omitted). */
  readonly assetId?: string;
  /** Generate thumbnails when the MIME type supports it (default `true`). */
  readonly generateThumbnail?: boolean;
}

/**
 * The MASKED `save` result. Carries ONLY opaque media references; the four
 * filesystem-path members of the canonical `SaveMediaResult` are STRUCTURALLY
 * ABSENT — each is typed `?: never` (not merely omitted) so any masked value
 * that carried a populated path is a COMPILE error at the adapter boundary.
 * This is the structural half of the O13 double-enforcement.
 */
export interface HostMaskedSaveMediaResult {
  /** Stable asset id. */
  readonly assetId: string;
  /** `media://localhost/…` URL — the frontend's canonical media reference. */
  readonly fileUrl: string;
  /** The stored media's MIME type. */
  readonly mimeType: string;
  /** `media://` URL of the generated thumbnail, when one was generated. */
  readonly thumbnailUrl?: string;
  /** `media://` URL of the medium thumbnail, when one was generated. */
  readonly mediumThumbnailUrl?: string;
  /** Inline medium-thumbnail bytes (base64), when generated. */
  readonly mediumThumbnailBase64?: string;
  /** MIME type of the medium thumbnail (when `mediumThumbnailBase64` rides). */
  readonly mediumThumbnailMimeType?: string;
  /**
   * STRUCTURALLY ABSENT — stored-form path (userData-relative tail in-root,
   * else absolute). Typed `?: never`: a populated value fails to type-check.
   */
  readonly filePath?: never;
  /**
   * STRUCTURALLY ABSENT — runtime absolute path. Typed `?: never`: a
   * populated value fails to type-check.
   */
  readonly absoluteFilePath?: never;
  /** STRUCTURALLY ABSENT — thumbnail filesystem path (`?: never`). */
  readonly thumbnailPath?: never;
  /** STRUCTURALLY ABSENT — medium-thumbnail filesystem path (`?: never`). */
  readonly mediumThumbnailPath?: never;
}

/**
 * `host.services.mediaStorage` — the media-storage capability port. The three
 * core `MediaGenerationStorage` primitives, thin-wrapping the SAME
 * `MediaStorageService` singleton that mints `media://` references for the
 * media tools bridge (one storage, one reference shape). `save` returns are
 * masked (see {@link HostMaskedSaveMediaResult}); `readAsBase64` /
 * `resolveMediaUrl` forward to the singleton / the class's STATIC
 * `fromMediaUrl` resolver (the instance carries no such method) with the
 * argument unchanged.
 */
export interface HostMediaStorageLike {
  /**
   * Persist base64 media under `media/<sessionId>/<messageId>/` (minting a
   * `media://` reference + optional thumbnails) and return the MASKED result
   * — no filesystem path member crosses.
   */
  save(input: HostMediaStorageSaveInput): Promise<HostMaskedSaveMediaResult>;
  /**
   * Read a stored media file as base64 (the legacy read primitive), or `null`
   * when unreadable. Forwards to the singleton with the argument unchanged.
   */
  readAsBase64(ref: string): Promise<string | null>;
  /**
   * Resolve a `media://` (or `file://`) URL to a readable local ref, or
   * `null`. Await this method: isolated plugins resolve over RPC; in-process
   * adapters may return synchronously. Resolution is backed by the service
   * class's STATIC `fromMediaUrl` (the instance carries no such method — the
   * core port documents this same name gap).
   */
  resolveMediaUrl(url: string): string | null | Promise<string | null>;
}
