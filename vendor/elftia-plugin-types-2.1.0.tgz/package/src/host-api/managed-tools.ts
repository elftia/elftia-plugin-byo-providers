import type { HostToolHostDescriptorLike } from './tool-hosts';

/** Private registered launch configuration; never expose environment values to Agent/UI. */
export interface HostManagedToolRuntime {
  readonly pluginId: string;
  readonly toolId: string;
  readonly launch: HostToolHostDescriptorLike['launch'];
}

/** Private backend execution endpoint. Never expose its secret to a toolkit result or UI. */
export interface HostManagedToolTarget {
  readonly target: { readonly id: string; readonly projectPath: string; readonly port: number };
  readonly secret: { readonly id: string; readonly port: number; readonly token: string };
}

export interface HostManagedToolScope {
  readonly sessionId: string;
  readonly toolId: string;
  /** Existing project directory relative to the session's persisted workspace. */
  readonly projectRelativePath: string;
}

/** Supervision of registered tools; no executable, environment or arbitrary host may be supplied. */
export interface HostManagedToolsLike {
  describeRuntime(input: { readonly toolId: string }): Promise<HostManagedToolRuntime>;
  ensurePrepared(input: { readonly runtimeId: string }): Promise<{ readonly root: string }>;
  open(input: HostManagedToolScope): Promise<HostManagedToolTarget>;
  resolve(input: HostManagedToolScope): Promise<HostManagedToolTarget | null>;
  /**
   * Optional physical Host capability. Loads a registered target in an isolated hidden surface.
   * relativeUrl is an origin-relative URL template; only {token} may be substituted.
   * Completion means page loaded; protocol-specific render readiness belongs to the plugin.
   */
  ensureSurface?(
    input: HostManagedToolScope & {
      readonly targetId: string;
      readonly relativeUrl: string;
    }
  ): Promise<void>;
  /** Release only this plugin's ownership of a target surface; other owners remain intact. */
  releaseSurface?(input: { readonly targetId: string }): Promise<void>;
}
