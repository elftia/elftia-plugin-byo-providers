/**
 * host-api/canvas-generation.ts — `HostCanvasGenerationLike`, the
 * `host.services.generation` capability port (`canvas-host-adapter-ports`
 * T0c, host-API v1.59; owner ruling O13).
 *
 * A THIN, UNMASKED forwarding of the SEVEN existing core `generation:`
 * verbs — `runsList` / `runsStart` / `chainsStart` / `chainsRerun` /
 * `outputsRegisterBatch` / `provenanceGet` / `flowGet` — one-to-one onto
 * `generation:runs.list` / `runs.start` / `chains.start` / `chains.rerun` /
 * `outputs.registerBatch` / `provenance.get` / `flow.get` through the core
 * host dispatch (the SAME registered handlers the renderer IPC path uses;
 * one execution model). The member name is the ruling's own vocabulary
 * (`canvasScene / generation / media storage`, target-state §5) and the
 * forwarded core domain's own namespace.
 *
 * ── THE NON-NEGOTIABLE POSTURE (O13: "不 mask、本来就要给插件/agent 用") ──
 * - NO new verbs: the seven methods map one-to-one onto existing channels;
 *   nothing is invented, nothing else is forwarded.
 * - NO result masking or reshaping: a method returns the handler's raw
 *   shape. Start-verb results include the handler's NATIVE `completionEvent`
 *   INLINE — the port does not strip it and does not re-emit `onRunCompleted`
 *   (that strip + push is the renderer IPC path's reroute wrapper, a
 *   renderer-caller concern; an in-process consumer takes the inline event
 *   as the terminal state).
 * - NO softening: a core rejection (e.g. the rerun source guard's
 *   "Rerun source is not a terminal genuine image run") propagates as a
 *   rejection with its message INTACT — never rewritten, swallowed, or
 *   translated.
 *
 * ── WHY RAW `sessionId` HERE (a ruling boundary, not an oversight) ──
 * O13 scoped the opaque-handle ruling to the `canvasScene` port; the core
 * generation verbs' own inputs are raw session ids, and this port is a
 * faithful thin forwarding of them. The MODEL-facing closure lives in the
 * S09 child-2 toolkit: its functions source `sessionId` from the
 * host-injected toolkit context, NEVER from model arguments (otherwise the
 * model could enumerate other sessions through `runsList` / `provenanceGet`
 * / `flowGet`).
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it. The inputs are
 * STRUCTURAL LOWER BOUNDS of the shared Zod schemas the matching IPC handler
 * validates with (the adapter re-validates with those SAME schemas — no
 * schema fork); a host-side builtin consumer may re-narrow against
 * `@elftia/shared` contract types.
 *
 * @module @elftia/plugin-types/host-api/canvas-generation
 */

/**
 * One ordered registered canvas artifact selected as a chain source — a
 * structural lower bound of the shared `GenerationChainSource`
 * (`{ artifactId, mode }`).
 */
export interface HostGenerationChainSource {
  /** The registered output's artifact id (a `media://`-referencing row id). */
  readonly artifactId: string;
  /** Input-resolution policy when the chain execution is admitted. */
  readonly mode: 'freeze' | 'live';
  readonly [key: string]: unknown;
}

/** `runsList` input — structural lower bound of the shared list schema. */
export interface HostGenerationRunsListInput {
  /** The session whose runs (with outputs + inputs) are listed. */
  readonly sessionId: string;
  readonly [key: string]: unknown;
}

/**
 * `runsStart` input — structural lower bound of the shared
 * `GenerationRunsStartInputSchema` (`GenerationImageExecutionConfigSchema` +
 * `inputs`): user input/config ONLY — bytes and data URLs have no contract
 * slot; references are canonical `media://` strings.
 */
export interface HostGenerationRunsStartInput {
  readonly sessionId: string;
  /** The generation prompt (non-empty). */
  readonly prompt: string;
  /** Media provider id (BYO-configured). */
  readonly providerId: string;
  /** Provider model id. */
  readonly modelId: string;
  /** Positive image count (≤14). */
  readonly imageCount: number;
  readonly [key: string]: unknown;
}

/**
 * `chainsStart` input — structural lower bound of the shared
 * `GenerationChainsStartInputSchema`: the execution config PLUS the ordered
 * chain sources (≥1; empty sources is a schema violation and rejects before
 * any dispatch).
 */
export interface HostGenerationChainsStartInput {
  readonly sessionId: string;
  readonly prompt: string;
  readonly providerId: string;
  readonly modelId: string;
  readonly imageCount: number;
  /** Ordered registered-artifact sources (non-empty; core resolves them). */
  readonly sources: readonly HostGenerationChainSource[];
  readonly [key: string]: unknown;
}

/**
 * `chainsRerun` input — structural lower bound of the shared rerun schema.
 * The rerun source guard (terminal, genuine, image, same-session) lives in
 * core and rejects with its original message.
 */
export interface HostGenerationChainsRerunInput {
  readonly sessionId: string;
  /** The immutable terminal attempt to rerun. */
  readonly runId: string;
  /** Frozen or live input resolution for the rerun. */
  readonly inputMode: 'freeze' | 'live';
  readonly [key: string]: unknown;
}

/**
 * `outputsRegisterBatch` input — structural lower bound of the shared batch
 * schema (`outputIds` unique, non-empty).
 */
export interface HostGenerationOutputsRegisterBatchInput {
  readonly sessionId: string;
  readonly runId: string;
  /** The run's exact unique output set, registered as one stack. */
  readonly outputIds: readonly string[];
  readonly [key: string]: unknown;
}

/** `provenanceGet` input — structural lower bound of the provenance schema. */
export interface HostGenerationProvenanceGetInput {
  readonly sessionId: string;
  /** The registered artifact id the provenance question is asked about. */
  readonly outputId: string;
  readonly [key: string]: unknown;
}

/** `flowGet` input — structural lower bound of the flow-graph schema. */
export interface HostGenerationFlowGetInput {
  readonly sessionId: string;
  readonly [key: string]: unknown;
}

/**
 * A generation-verb result — the handler's RAW shape as an opaque structural
 * record. NOT masked, NOT reshaped (O13): start verbs carry the handler's
 * native `completionEvent` inline; the consumer re-narrows against the
 * shared contract types.
 */
export type HostGenerationOpaqueResult = { readonly [key: string]: unknown };

/**
 * `host.services.generation` — the seven core generation verbs, thinly
 * forwarded. Each method validates its payload with the SAME shared Zod
 * schema the matching IPC handler validates with (rejecting before any
 * dispatch on violation), then dispatches the one core channel and returns
 * the handler's result unchanged.
 */
export interface HostCanvasGenerationLike {
  /** → `generation:runs.list` — the session's runs with outputs + inputs. */
  runsList(input: HostGenerationRunsListInput): Promise<HostGenerationOpaqueResult>;
  /** → `generation:runs.start` — start a run (result carries `completionEvent`). */
  runsStart(input: HostGenerationRunsStartInput): Promise<HostGenerationOpaqueResult>;
  /** → `generation:chains.start` — canvas-policy start over registered sources. */
  chainsStart(input: HostGenerationChainsStartInput): Promise<HostGenerationOpaqueResult>;
  /** → `generation:chains.rerun` — rerun one terminal attempt (guard in core). */
  chainsRerun(input: HostGenerationChainsRerunInput): Promise<HostGenerationOpaqueResult>;
  /** → `generation:outputs.registerBatch` — register a run's outputs as a stack. */
  outputsRegisterBatch(
    input: HostGenerationOutputsRegisterBatchInput
  ): Promise<HostGenerationOpaqueResult>;
  /** → `generation:provenance.get` — the provenance report for one artifact. */
  provenanceGet(input: HostGenerationProvenanceGetInput): Promise<HostGenerationOpaqueResult>;
  /** → `generation:flow.get` — the session's derived run graph (node-flow). */
  flowGet(input: HostGenerationFlowGetInput): Promise<HostGenerationOpaqueResult>;
}
