/** Backend-only execution facts. Plugins retain their own projects, jobs and candidate routing. */
export interface HostMediaExecutionScope {
  readonly sessionId: string;
  readonly ownerKey: string;
  readonly requestKey: string;
  readonly requestHash: string;
}

export interface HostMediaExecutionInput {
  readonly slot: string;
  readonly relativePath: string;
  readonly sha256: string;
  readonly sizeBytes: number;
  readonly mediaKind: 'image' | 'video' | 'audio';
}

export interface HostMediaExecutionRequest {
  readonly scope: HostMediaExecutionScope;
  /** Current authorized session; scope.sessionId retains the original request provenance. */
  readonly accessSessionId?: string;
  readonly config: Readonly<Record<string, unknown>>;
  /** Fixed files relative to the Host-resolved persisted session workspace. */
  readonly inputs: readonly HostMediaExecutionInput[];
}

export interface HostMediaExecutionOutput {
  readonly id: string;
  readonly runId: string;
  readonly mediaRef: string;
  readonly mimeType: string;
  readonly sha256: string;
  readonly sizeBytes: number;
}

export type HostMediaExecutionObservation = {
  readonly runId: string;
  readonly scope: HostMediaExecutionScope;
} & (
  | { readonly status: 'running' }
  | { readonly status: 'unknown'; readonly reason: string }
  | { readonly status: 'failed'; readonly reason: string }
  | { readonly status: 'cancelled'; readonly reason?: string }
  | { readonly status: 'completed'; readonly outputs: readonly HostMediaExecutionOutput[] }
);

/** Main-context capability; no bytes, provider secrets or arbitrary paths cross the wire. */
export interface HostMediaExecutionLike {
  prepare(
    input: HostMediaExecutionRequest
  ): Promise<
    { readonly status: 'available' } | { readonly status: 'unavailable'; readonly reason: string }
  >;
  /** Acknowledges durable admission, then the Host owns drainage of the accepted attempt. */
  start(
    input: HostMediaExecutionRequest & { readonly runId: string }
  ): Promise<HostMediaExecutionObservation>;
  observe(input: {
    readonly runId: string;
    readonly scope: HostMediaExecutionScope;
    readonly accessSessionId?: string;
  }): Promise<HostMediaExecutionObservation | null>;
  /** Materializes verified bytes in Host cache; the backend consumes this private file directly. */
  materializeOutput(input: {
    readonly runId: string;
    readonly outputId: string;
    readonly scope: HostMediaExecutionScope;
    readonly accessSessionId?: string;
  }): Promise<{ readonly output: HostMediaExecutionOutput; readonly absolutePath: string }>;
  /** Best effort. Never treats an acknowledgement as confirmed provider termination. */
  requestCancel(input: {
    readonly runId: string;
    readonly scope: HostMediaExecutionScope;
    readonly accessSessionId?: string;
  }): Promise<void>;
}
