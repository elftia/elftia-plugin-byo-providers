import type { HostUnregister } from './_shared';

/** The embedding host supplies scope; the embedded document cannot choose it. */
export interface ToolHostContentRequest {
  readonly sessionId: string;
  readonly projectPath: string;
  readonly connectionId: string;
  readonly method: 'snapshot' | 'execute' | 'disconnect';
  readonly command?: unknown;
  /** Explicit opt-in; older hosts omit this field. */
  readonly transport?: { readonly version: 1; readonly knownRevision?: string };
}

export interface ToolHostContentRegistration {
  readonly toolId: string;
  readonly protocol: {
    readonly request: string;
    readonly response: string;
    readonly changed: string;
    readonly invalidated: string;
  };
  readonly handle: (request: ToolHostContentRequest) => Promise<{
    readonly result: unknown;
    /** Scoped to the embedding Host session/tab; commands cannot choose a destination. */
    readonly effects?: readonly (
      | { readonly type: 'canvas.locate'; readonly elementIds: readonly string[] }
      | { readonly type: 'composer.insert'; readonly text: string }
    )[];
  }>;
}

/** Data-only integration for an admitted tool surface; does not expose IPC or credentials. */
export interface HostToolHostContent {
  register(registration: ToolHostContentRegistration): HostUnregister;
  invalidate(toolId: string, sessionId: string): Promise<void>;
}
