/** Toolkit handlers and original validators remain local; JSON schemas only describe discovery. */
import type { HostUnregister } from './_shared';

export interface HostToolkitFunctionLike {
  readonly name: string;
  readonly schema: unknown;
  readonly discoverySchema?: HostToolkitJsonSchema;
  /** Backend-declared media result fields. Segments are own object keys; '*' expands arrays only.
   * UI grants come from these fields, never from arbitrary strings in documents or arguments. */
  readonly mediaResultPaths?: readonly (readonly string[])[];
  readonly [key: string]: unknown;
}

export interface HostToolkitSpecLike {
  readonly name: string;
  readonly description: string;
  readonly skillMarkdown: string;
  readonly functions: readonly HostToolkitFunctionLike[];
  /** Trusted writer control plane; never exposed as an Agent-callable function. */
  readonly scopeLifecycle?: HostToolkitScopeLifecycle;
  readonly [key: string]: unknown;
}

export interface HostToolkitsBackend {
  register(spec: HostToolkitSpecLike): HostUnregister;
}

export type HostToolkitJsonValue =
  | null
  | boolean
  | number
  | string
  | readonly HostToolkitJsonValue[]
  | { readonly [key: string]: HostToolkitJsonValue };
export type HostToolkitJsonSchema = boolean | { readonly [key: string]: HostToolkitJsonValue };

export interface HostToolkitInvocationIdentity {
  readonly invocationId: string;
  readonly registrationId: string;
  readonly generation: number;
}

export interface HostToolkitAuthorityRef {
  readonly authorizationRef: string;
  readonly authorizationGeneration: number;
}
export interface HostToolkitScopeGrant extends HostToolkitAuthorityRef {
  readonly workspacePath: string;
  readonly sessionId?: string;
}
export interface HostToolkitScopeLifecycle {
  grant(scope: HostToolkitScopeGrant): void | Promise<void>;
  revoke(ref: HostToolkitAuthorityRef): void | Promise<void>;
}
export interface HostToolkitInvocationAuthority extends HostToolkitAuthorityRef {
  beginCommit(): Promise<{ readonly leaseId: string }>;
  endCommit(leaseId: string, outcome: 'committed' | 'aborted' | 'unknown'): Promise<void>;
}

export interface HostToolkitCancellationSignal {
  readonly aborted: boolean;
  addEventListener(type: 'abort', listener: () => void, options?: { once?: boolean }): void;
  removeEventListener(type: 'abort', listener: () => void): void;
}

export interface HostToolkitInvocationContext {
  /** Host-issued scopes for explicit multi-workspace UI operations. Never parsed from args. */
  readonly relatedScopes?: readonly Omit<HostToolkitInvocationContext, 'relatedScopes'>[];
  readonly pluginId?: string;
  readonly workspacePath: string;
  readonly channelId?: string;
  readonly chatId?: string;
  readonly agentId?: string;
  readonly sessionId?: string;
  readonly invocation: HostToolkitInvocationIdentity;
  readonly authority?: HostToolkitInvocationAuthority;
  readonly signal?: HostToolkitCancellationSignal;
}
