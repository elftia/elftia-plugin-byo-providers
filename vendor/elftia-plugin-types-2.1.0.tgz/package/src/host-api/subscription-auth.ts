/**
 * host-api/subscription-auth.ts — `HostSubscriptionAuthLike`, the
 * `host.services.subscriptionAuth` capability port (`byo-port-subscription-auth`,
 * host-API v1.22).
 *
 * Lets a Tier-1 main plugin (the future `byo-providers` plugin) drive
 * subscription / OAuth / CLI-account management WITHOUT the host owning that UI:
 * OAuth flow initiation, CLI-login import, account add/remove/switch, and the
 * OpenCodeGo static-bearer subscription config.
 *
 * ── TOKEN-NEVER-CROSSES INVARIANT (design D2 — the crux) ──
 * No method on this port returns an access token, refresh token, id token, setup
 * token, or provider API key. The invariant is ARCHITECTURAL, not allowlist-
 * based: subscription tokens live in the host's OWN encrypted `account-tokens`
 * electron-store (NOT a BYO secret-ref), the host performs every OAuth code→token
 * exchange + persistence + refresh, and every read is a sanitized descriptor.
 *   - OAuth init returns ONLY a public auth URL + `state` — the PKCE
 *     `code_verifier` STAYS HOST-SIDE (retained keyed by `state`); it is NOT in
 *     {@link HostOAuthInitParams} and never crosses to the plugin. At exchange
 *     time the plugin relays back ONLY the short-lived authorization `code` (+
 *     `state`); the host looks the verifier up by `state` and runs the exchange.
 *   - Exchange / refresh / mutate methods return status only
 *     ({@link HostSubscriptionOpResult} / `boolean`).
 *   - Reads return sanitized descriptors ({@link HostAccountTokensSanitized} /
 *     {@link HostSubscriptionAccountSanitized}) carrying only `has*Token`
 *     booleans + display fields.
 *   - An inbound user-entered key (`setOpenCodeGoConfig`'s `apiKey`) is carried
 *     INWARD only — consumed host-side into the store and NEVER echoed back.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it.
 * No DOM type leaks in. Like `HostLlmConfigLike`, the payload shapes are
 * STRUCTURAL LOWER BOUNDS (Node-shaped, no `@main`/`@shared` import) — the host's
 * canonical `AccountTokensSanitized` / `SubscriptionAccountSanitized` /
 * `CliImportResult` are structurally assignable, and the plugin re-narrows what
 * it reads.
 *
 * @module @elftia/plugin-types/host-api/subscription-auth
 */

/**
 * The OAuth-init descriptor the port returns. Pins ONLY the public redirect URL
 * + the opaque `state` correlator. The PKCE `code_verifier` is DELIBERATELY
 * ABSENT — it is retained host-side keyed by `state` and never crosses to the
 * plugin (the crux: the verifier is the PKCE secret that proves token-request
 * authenticity; handing it to a less-trusted boundary would let the holder
 * complete the flow). Canonical host `OAuthParams` MINUS `codeVerifier`.
 */
export interface HostOAuthInitParams {
  /** The public OAuth authorization URL the user opens to grant access. */
  readonly authUrl: string;
  /** The opaque state correlator the plugin relays back at exchange time. */
  readonly state: string;
}

/**
 * The exchange request the plugin relays back. Carries ONLY the short-lived
 * authorization `code` (NOT a credential) + the `state` correlator and an
 * optional account `label`. The PKCE `code_verifier` is NOT supplied by the
 * plugin — the host looks it up by `state` from its own retained store.
 */
export interface HostOAuthExchangeRequest {
  /** The short-lived OAuth authorization code the user pasted/redirected back. */
  readonly authorizationCode: string;
  /** The state correlator returned by the matching `get*AuthParams` call. */
  readonly state: string;
  /** Optional user-chosen display label for the appended account. */
  readonly label?: string;
}

/**
 * A status-only op result envelope ({@link HostSubscriptionAuthLike} mutations).
 * Carries no token / refresh-token / api-key field — only success + an optional
 * machine-readable error, an optional `expiresAt` (exchange), and an optional
 * `externalSync` status descriptor (account-mutation CLI sync). Remaining
 * envelope fields are opaque BUT the contract guarantees none is a credential.
 */
export interface HostSubscriptionOpResult {
  readonly success: boolean;
  /** Machine-readable failure reason (never a credential). */
  readonly error?: string;
  /** ISO expiry of the newly stored credential (exchange) — a timestamp, not a token. */
  readonly expiresAt?: string;
  /** External-CLI sync status descriptor (account ops) — `{ ok, reason?, error? }`. */
  readonly externalSync?: { readonly ok: boolean; readonly reason?: string; readonly error?: string };
  /**
   * When a `{ verify: true }` manual-token setter REFUSED the write (v1.72,
   * `subscription-token-probe`): the secret-free probe outcome that caused
   * the refusal. Present ONLY on a verify-refused failure — a persisted
   * success or a non-verify failure never carries it, and it NEVER echoes
   * token material or raw upstream error bodies.
   */
  readonly verifyFailure?: HostManualTokenVerifyFailure;
}

/**
 * The structured, secret-free reason a `{ verify: true }` manual-token setter
 * refused to persist (v1.72): which provider, which probe tier answered, and
 * the HTTP status or a sanitized reason code. Mirrors the daemon
 * `AccountConnectionProbeOutcome` discipline — a diagnostic for the UI to
 * SHOW, never credential material.
 */
export interface HostManualTokenVerifyFailure {
  /** The provider the probe ran against (e.g. `'codex'`). */
  readonly provider: string;
  /** Which tier answered: `'local'` (credential-presence) or `'upstream'`. */
  readonly tier: 'local' | 'upstream';
  /** The upstream HTTP status, when the probe reached one. */
  readonly status?: number;
  /** A sanitized reason code (never a raw upstream body). */
  readonly reason?: string;
}

/**
 * Optional manual-token setter options (v1.72, `subscription-token-probe`).
 * ADDITIVE: older plugin bytes call the setters without it and keep the exact
 * pre-v1.72 persist-always semantics.
 */
export interface HostManualTokenSetOptions {
  /**
   * Verify-before-persist: run the zero-cost token probe FIRST; persist ONLY
   * on a pass. On a fail the store stays byte-unchanged (no partial write)
   * and the return carries `{ success: false, verifyFailure }`. Absent or
   * `false` ⇒ the pre-v1.72 behavior, byte-identical.
   */
  readonly verify?: boolean;
}

/**
 * Result of a CLI-credential re-import. Status + an optional one-shot-refresh
 * flag; NEVER carries a credential. Canonical host `CliImportResult`.
 */
export interface HostCliImportResult {
  readonly success: boolean;
  /** Machine-readable failure reason (never a credential). */
  readonly error?: string;
  /** True when a one-shot refresh ran after import (imported token was expired). */
  readonly refreshed?: boolean;
}

/**
 * A single sanitized subscription account (display-only). Carries `hasAccessToken`
 * — a BOOLEAN, never the token — plus display fields. Canonical host
 * `SubscriptionAccountSanitized`. NO `accessToken`/`refreshToken`/`idToken`/
 * `apiKey` field is typeable here.
 */
export interface HostSubscriptionAccountSanitized {
  readonly id: string;
  readonly label?: string;
  /** Display status (`'authorized' | 'expired' | …`) — opaque string. */
  readonly status: string;
  readonly authMethod?: string;
  readonly subscriptionLevel?: string;
  readonly expiresAt?: string;
  readonly lastRefreshedAt?: string;
  readonly isSetupToken?: boolean;
  /** Whether an access token is stored — a presence boolean, NEVER the token. */
  readonly hasAccessToken: boolean;
  readonly isActive: boolean;
  /** Remaining display fields opaque — see canonical `SubscriptionAccountSanitized`. */
  readonly [key: string]: unknown;
}

/**
 * The sanitized whole-config view (display-only). Every per-provider block
 * surfaces only `has*Token` presence booleans + display fields; the per-provider
 * account arrays are {@link HostSubscriptionAccountSanitized}[]. Canonical host
 * `AccountTokensSanitized`. The index signature keeps the rest opaque BUT the
 * contract guarantees no raw token is typeable.
 */
export interface HostAccountTokensSanitized {
  /** Remaining sanitized blocks are opaque (presence booleans + display only). */
  readonly [key: string]: unknown;
}

/** A sanitized subscription catalog/status entry (display-only; no credential). */
export type HostSubscriptionEntry = { readonly [key: string]: unknown };

/** A subscription credential-refresh status result (no credential). */
export interface HostSubscriptionRefreshResult {
  readonly success: boolean;
  /** Machine-readable reason on failure. */
  readonly reason?: string;
  /** Optional error detail (never a credential). */
  readonly error?: string;
}

/**
 * Display-only view of one in-flight Kimi device flow (v1.63). Carries the
 * verification URL + user code + coarse state — NEVER the `deviceCode` and
 * never tokens. The host retains the deviceCode keyed by `sessionId`.
 */
export interface HostKimiDeviceFlowView {
  readonly sessionId: string;
  readonly state: 'pending' | 'done' | 'error';
  readonly verificationUri: string;
  readonly verificationUriComplete?: string;
  readonly userCode: string;
  readonly error?: string;
}

/**
 * Display-only view of one in-flight Grok / Copilot device flow (v1.65) — the
 * same token-free shape as {@link HostKimiDeviceFlowView}. Copilot flows may
 * carry the normalized `enterpriseUrl` back for display when a GitHub
 * Enterprise domain was supplied at start.
 */
export interface HostDeviceFlowView {
  readonly sessionId: string;
  readonly state: 'pending' | 'done' | 'error';
  readonly verificationUri: string;
  readonly verificationUriComplete?: string;
  readonly userCode: string;
  readonly error?: string;
  /** Copilot only: the normalized GHE domain riding this flow (absent = personal). */
  readonly enterpriseUrl?: string;
}

/**
 * Token-free start result for the codex loopback sign-in (v1.67):
 * `ok: true` carries the `authUrl` to open (the browser's redirect to
 * `localhost:1455/auth/callback` is captured HOST-side — no code to paste);
 * `ok: false` carries a display-safe reason (e.g. a sign-in already in
 * flight — the single loopback port is held).
 */
export type HostCodexLoopbackStart =
  | { ok: true; authUrl: string; sessionId: string }
  | { ok: false; error: string };

/** Token-free polled status of one codex loopback sign-in (v1.67). */
export interface HostCodexLoopbackStatus {
  readonly sessionId: string;
  readonly state: 'pending' | 'done' | 'error';
  readonly error?: string;
}

/**
 * The Claude subscription level a manual-token paste / update may carry inward
 * (`'Free' | 'Pro' | 'Max' | …`). A plain display/level string at the contract
 * boundary (the host's `SubscriptionLevel` enum stays the validation SSOT).
 */
export type HostClaudeSubscriptionLevel = string;

/**
 * `host.services.subscriptionAuth` — the subscription / OAuth / CLI-account port.
 *
 * Every method Zod-validates its payload (≥ the corresponding IPC handler,
 * reusing the same schemas) before delegating to the host's `TokensService`
 * (+ the host token-refresh service where the IPC path uses it). The HOST runs
 * every OAuth exchange, token persistence, and refresh; the plugin only triggers
 * flows + reads status.
 *
 * ── v1.26 (`byo-p2-subscription` D4) — manual-token write verbs ADDED ──
 * The manual raw-token paste setters (`setClaudeManualToken` / `setCodexManualToken`
 * / `setGeminiManualToken` / `updateClaudeSubscriptionLevel`), deferred from v1 as
 * "write-in only, additive later", are NOW present. They are INWARD-only: the pasted
 * access token / refresh token / level is consumed host-side into the encrypted
 * `account-tokens` store and the return is STATUS only (`{ success, error? }`) — no
 * token is echoed OUT, fitting the no-token-OUT invariant exactly.
 */
export interface HostSubscriptionAuthLike {
  // ── OAuth init (token NEVER returned; PKCE verifier stays host-side) ─────────
  /** Begin the Claude OAuth flow; returns ONLY `{ authUrl, state }` (no verifier). */
  getClaudeAuthParams(): Promise<HostOAuthInitParams>;
  /** Begin the Claude setup-token flow; returns ONLY `{ authUrl, state }`. */
  getClaudeSetupAuthParams(): Promise<HostOAuthInitParams>;
  /** Begin the Codex OAuth flow; returns ONLY `{ authUrl, state }`. */
  getCodexAuthParams(): Promise<HostOAuthInitParams>;
  /** Begin the Gemini OAuth flow; returns ONLY `{ authUrl, state }`. */
  getGeminiAuthParams(): Promise<HostOAuthInitParams>;
  /**
   * Begin the Kimi RFC 8628 device flow; returns ONLY display fields
   * (`verificationUri`, `userCode`, `sessionId`). The `deviceCode` stays
   * HOST-side (v1.63) — the plugin polls {@link pollKimiDeviceFlow}.
   */
  startKimiDeviceFlow(): Promise<HostKimiDeviceFlowView>;
  /**
   * Poll a Kimi device flow once: `pending` / `done` / `error` (the host
   * persists the completed credential as an account on `done`). No token and
   * no deviceCode ever cross (v1.63).
   */
  pollKimiDeviceFlow(sessionId: string): Promise<HostKimiDeviceFlowView>;
  /** Abandon a Kimi device flow (v1.63); idempotent. */
  cancelKimiDeviceFlow(sessionId: string): Promise<void>;
  /**
   * Begin the Grok (xAI SuperGrok) RFC 8628 device flow; display fields only
   * (v1.65) — the `deviceCode` stays HOST-side, the plugin polls
   * {@link pollGrokDeviceFlow}.
   */
  startGrokDeviceFlow(): Promise<HostDeviceFlowView>;
  /** Poll a Grok device flow once (v1.65); no token/deviceCode ever cross. */
  pollGrokDeviceFlow(sessionId: string): Promise<HostDeviceFlowView>;
  /** Abandon a Grok device flow (v1.65); idempotent. */
  cancelGrokDeviceFlow(sessionId: string): Promise<void>;
  /**
   * Begin the GitHub Copilot RFC 8628 device flow (v1.65). The optional
   * `enterpriseUrl` (bare host or full URL) routes the whole chain onto a
   * GitHub Enterprise host and is normalized HOST-side — an invalid domain
   * rejects the call.
   */
  startCopilotDeviceFlow(enterpriseUrl?: string): Promise<HostDeviceFlowView>;
  /**
   * Poll a Copilot device flow once: `pending` / `done` (the host ran the
   * post-approval identity + endpoint-discovery + policy-enable chain) /
   * `error` (v1.65). No token/deviceCode ever cross.
   */
  pollCopilotDeviceFlow(sessionId: string): Promise<HostDeviceFlowView>;
  /** Abandon a Copilot device flow (v1.65); idempotent. */
  cancelCopilotDeviceFlow(sessionId: string): Promise<void>;
  /**
   * Begin the codex sign-in with the AUTO-COMPLETE loopback listener (v1.67):
   * the host binds `127.0.0.1:1455`, so the browser's OAuth redirect is
   * captured host-side and exchanged WITHOUT any code paste. Open the returned
   * `authUrl` and poll {@link pollCodexLoopbackLogin} for the token-free
   * outcome. The PKCE verifier and every token stay HOST-side.
   */
  startCodexLoopbackLogin(): Promise<HostCodexLoopbackStart>;
  /**
   * Poll one codex loopback sign-in (v1.67): `pending` while awaiting the
   * browser callback, `done` after the host exchanged + appended the account,
   * `error` on capture/exchange failure. NEVER carries a token.
   */
  pollCodexLoopbackLogin(sessionId: string): Promise<HostCodexLoopbackStatus>;
  /** Abandon one codex loopback sign-in (v1.67); idempotent. */
  cancelCodexLoopbackLogin(sessionId: string): Promise<void>;
  /**
   * Complete the Claude exchange. The plugin relays back ONLY `{ authorizationCode,
   * state, label? }`; the host looks up the retained PKCE verifier by `state`,
   * runs `exchangeCodeForTokens` + appends the account, and returns status only.
   */
  exchangeClaudeToken(request: HostOAuthExchangeRequest): Promise<HostSubscriptionOpResult>;
  /** Complete the Claude setup-token exchange (host-side); status only. */
  exchangeClaudeSetupToken(request: HostOAuthExchangeRequest): Promise<HostSubscriptionOpResult>;
  /** Complete the Codex exchange (host-side); status only. */
  exchangeCodexToken(request: HostOAuthExchangeRequest): Promise<HostSubscriptionOpResult>;
  /** Complete the Gemini exchange (host-side); status only. */
  exchangeGeminiToken(request: HostOAuthExchangeRequest): Promise<HostSubscriptionOpResult>;

  // ── CLI import (credential NEVER returned) ──────────────────────────────────
  /** Re-import the active account's credential from the external CLI store. */
  importFromExternalCli(platform: string): Promise<HostCliImportResult>;
  /** Read the auto-import-on-refresh-failure toggle for a CLI provider. */
  getCliAutoImport(provider: string): Promise<boolean>;
  /** Set the auto-import-on-refresh-failure toggle for a CLI provider. */
  setCliAutoImport(provider: string, enabled: boolean): Promise<void>;

  // ── Account management (descriptors only) ───────────────────────────────────
  /** The sanitized whole-config view (display-only; `has*Token` booleans). */
  getSanitized(): Promise<HostAccountTokensSanitized>;
  /** List a provider's sanitized accounts (display-only; never raw tokens). */
  listAccounts(provider: string): Promise<HostSubscriptionAccountSanitized[]>;
  /** Switch the active account for a provider; status only. */
  setActiveAccount(provider: string, id: string): Promise<HostSubscriptionOpResult>;
  /** Remove an account; status only. */
  removeAccount(provider: string, id: string): Promise<HostSubscriptionOpResult>;
  /** Update an account's display label; status only. */
  updateAccountLabel(provider: string, id: string, label: string): Promise<HostSubscriptionOpResult>;
  /** Apply an account to the external CLI store; status only. */
  applyAccountToCli(provider: string, id: string): Promise<HostSubscriptionOpResult>;
  /** Trigger a host-side refresh of one account; returns a boolean (no token). */
  refreshAccount(provider: string, id: string): Promise<boolean>;
  /** Drop a provider's accounts + mirror; no token in/out. */
  clearConfig(platform: string): Promise<void>;

  // ── Subscription / OpenCodeGo ───────────────────────────────────────────────
  /** List the catalog of subscription providers (sanitized descriptors). */
  listSubscriptions(): Promise<HostSubscriptionEntry[]>;
  /** Per-provider credential status (sanitized; no credential). */
  subscriptionStatus(providerId: string): Promise<HostSubscriptionEntry>;
  /**
   * Persist OpenCodeGo config. The inbound `request.apiKey` is carried INWARD
   * only — consumed + stored host-side, NEVER echoed in the status-only return.
   */
  setOpenCodeGoConfig(request: Record<string, unknown>): Promise<HostSubscriptionOpResult>;
  /** Append a NEW OpenCodeGo account (inbound key consumed host-side); status only. */
  addOpenCodeGoAccount(request: Record<string, unknown>): Promise<HostSubscriptionOpResult>;
  /** Wipe the OpenCodeGo credentials; status only (idempotent). */
  clearOpenCodeGo(): Promise<HostSubscriptionOpResult>;
  /** Refresh a downstream subscription's credential host-side; status only. */
  refreshCredential(providerId: string): Promise<HostSubscriptionRefreshResult>;

  // ── Manual-token paste (v1.26; INWARD-only — token consumed host-side) ───────
  /**
   * Set a Claude access token pasted by the user. The `accessToken` (+ optional
   * `subscriptionLevel` / `label`) is carried INWARD only — consumed host-side
   * into the encrypted store + appended as an account; the status-only return
   * echoes NO token. The v1.72 `options.verify` runs the probe first and
   * persists only on a pass (see {@link HostManualTokenSetOptions}).
   */
  setClaudeManualToken(
    accessToken: string,
    subscriptionLevel?: HostClaudeSubscriptionLevel,
    label?: string,
    options?: HostManualTokenSetOptions,
  ): Promise<HostSubscriptionOpResult>;
  /**
   * Set a Codex access token pasted by the user. INWARD-only (consumed host-side
   * + appended as an account); status-only return (no token OUT). The v1.72
   * `options.verify` runs the probe first and persists only on a pass.
   */
  setCodexManualToken(
    accessToken: string,
    label?: string,
    options?: HostManualTokenSetOptions,
  ): Promise<HostSubscriptionOpResult>;
  /**
   * Set a Gemini access token (+ optional refresh token) pasted by the user.
   * INWARD-only (consumed host-side into the Gemini config); status-only return.
   * The v1.72 `options.verify` runs the probe first and persists only on a pass.
   */
  setGeminiManualToken(
    accessToken: string,
    refreshToken?: string,
    options?: HostManualTokenSetOptions,
  ): Promise<HostSubscriptionOpResult>;
  /**
   * Update the Claude subscription level (no token at all — a level string carried
   * INWARD into the stored config). Status-only return.
   */
  updateClaudeSubscriptionLevel(level: HostClaudeSubscriptionLevel): Promise<HostSubscriptionOpResult>;
  /**
   * Force a host-side refresh of the active Kimi account (v1.63); status only.
   */
  refreshKimiToken(): Promise<boolean>;
  /**
   * Force a host-side refresh of the active Grok account (v1.65); status only.
   */
  refreshGrokToken(): Promise<boolean>;
  /**
   * "Refresh" the active Copilot account (v1.65) — a LOCAL no-op restamp of
   * the far-future expiry (ghu_ tokens have no exchange endpoint); status only.
   */
  refreshCopilotToken(): Promise<boolean>;
  /**
   * Secret-free account allowance snapshot (v1.64) — normalized usage windows
   * for ONE internal account, read host-side by stable id. OPTIONAL
   * capability: older hosts omit it; call sites must feature-detect. Unknown /
   * unsupported quota is explicit (`unavailable` / `unsupported` window
   * states) — never a measured 0%.
   */
  getAccountAllowance?(
    providerId: string,
    accountId: string,
    force?: boolean,
  ): Promise<HostAccountAllowanceSnapshot>;
  /**
   * The per-provider subscription model view (v1.70) — built-in defaults +
   * user-added extras + the effective union, for the 订阅账号 tab's model
   * list display. OPTIONAL capability: older hosts omit it; feature-detect.
   * Data-only; no credentials are involved.
   */
  getSubscriptionModels?(): Promise<HostSubscriptionModelsView>;
  /**
   * REPLACE one provider's user-added extras (v1.70) — the caller's dialog owns
   * add/remove; the host persists the whole list. Returns the refreshed view.
   * OPTIONAL capability; fails closed when the host cannot persist.
   */
  setSubscriptionExtraModels?(
    providerId: string,
    models: HostSubscriptionModelInfo[],
  ): Promise<HostSubscriptionModelsView>;
  /** Toggle any built-in or user-added model (v1.71). */
  setSubscriptionModelEnabled?(
    providerId: string,
    modelId: string,
    enabled: boolean,
  ): Promise<HostSubscriptionModelsView>;
}

/** One model entry in the subscription model view (v1.70). `image` marks image models (e.g. codex gpt-image-2). */
export interface HostSubscriptionModelInfo {
  id: string;
  kind: 'chat' | 'image';
  enabled?: boolean;
}

/** Per-provider view (v1.70): built-in defaults + user-added extras + the effective union. */
export interface HostSubscriptionProviderModels {
  defaults: HostSubscriptionModelInfo[];
  extras: HostSubscriptionModelInfo[];
  effective: HostSubscriptionModelInfo[];
  configured?: boolean;
}

/** The whole subscription model view, keyed by provider id (v1.70). */
export type HostSubscriptionModelsView = Record<string, HostSubscriptionProviderModels>;

/** One normalized usage window (v1.64). Structural mirror of the wire DTO. */
export interface HostAllowanceWindow {
  id: string;
  label: string;
  scope: 'all' | 'model-family' | (string & {});
  modelFamily?: string;
  /** Percent used 0–100; `null` = unknown (NEVER rendered as measured 0). */
  usedPercent: number | null;
  windowMinutes?: number;
  resetsAt?: string;
  remainingSeconds?: number;
  state: 'fresh' | 'stale' | 'unavailable' | 'unsupported' | (string & {});
}

/** Secret-free allowance snapshot for one internal subscription account (v1.64). */
export interface HostAccountAllowanceSnapshot {
  providerId: string;
  accountId: string;
  source: 'oauth-usage-api' | 'response-headers' | (string & {});
  observedAt: string;
  expiresAt?: string;
  windows: HostAllowanceWindow[];
  /** Stable, display-safe diagnostic code — never an upstream body or token. */
  lastErrorCode?: string;
  primaryOverSecondaryLimitPercent?: number;
}
