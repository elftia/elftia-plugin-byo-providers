import type { HostReactNode, HostUnregister } from './_shared';

export type TemplateCategory =
  | 'image'
  | 'video'
  | 'audio'
  | 'web'
  | 'presentation'
  | 'document'
  | 'design-system'
  | 'content-pack';

/**
 * Data-only Use routing for one template item — what the host's generic Use
 * flow does when the card is activated (v1.69). Mirrors the new-chat handoff
 * payload: `agentId` targets a specific agent's session, `prompt` prefills
 * the composer, `context` rides verbatim as opaque modality keys. Routing
 * DATA only — the host never auto-sends and never branches on context keys;
 * executable configuration still lives with the owning plugin (`renderCard`).
 */
export interface TemplateUseRoute {
  /**
   * Target agent for the new session. Validated against the live agent list
   * at click time; absent or unknown ⇒ a picker-visible default chat.
   */
  readonly agentId?: string;
  /** Composer prefill; absent = assembled from the item title + description. */
  readonly prompt?: string;
  /**
   * Opaque modality-keyed payload passed verbatim into the new-chat prefill
   * (e.g. `designStudio: { mode, skillId }`). The host never interprets keys;
   * an `autoSend` key is rejected/stripped — a template must not send itself.
   */
  readonly context?: Record<string, unknown>;
}

/** Browsing metadata + data-only use routing; executable configuration stays with the owning plugin. */
export interface TemplateSourceItem {
  readonly id: string;
  readonly category: TemplateCategory;
  readonly title: string;
  readonly description?: string;
  readonly tags?: readonly string[];
  readonly source: 'mine' | 'preset';
  readonly updatedAt?: number;
  readonly useCount?: number;
  /**
   * Optional browsing subgroup within the category — e.g. `'programmatic'` vs
   * `'generative'` under video, or `'image'`/`'video'`/`'audio'` under web.
   * Free-form; the template page renders chip filters from the distinct
   * values present, not from a fixed vocabulary.
   */
  readonly subgroup?: string;
  /** Poster image for the host default card (resolved like community thumbnails). */
  readonly thumbnailUrl?: string;
  /** Optional hover-video preview for the host default card. */
  readonly previewVideoUrl?: string;
  /**
   * Aspect-ratio hint for the host default card's preview badge (e.g.
   * `'16:9'`). Presentation only — the preview tile stays 16:10 and
   * object-covers; the badge tells the true output ratio.
   */
  readonly aspect?: string;
  /** Data-only Use routing consumed by the host default card / generic Use flow. */
  readonly use?: TemplateUseRoute;
}

export interface TemplateSourceDefinition {
  readonly id: string;
  /** Plugin-resolved display text, never a host translation key. */
  readonly label: string;
  readonly categories: readonly TemplateCategory[];
  list(): Promise<readonly TemplateSourceItem[]>;
  /**
   * Optional custom card (v1.69 — previously required). Called as a render
   * function; return a component rather than calling Hooks here. When absent
   * the host renders its default card and the generic Use flow consumes
   * {@link TemplateSourceItem.use}.
   */
  renderCard?(itemId: string): HostReactNode;
}

/** @since 1.62 — contributes browsing metadata and cards without exposing host storage. */
export interface HostTemplates {
  registerSource(definition: TemplateSourceDefinition): HostUnregister;
}
