/** Host verifies the session and derives its workspace; UI never supplies authorization or paths. */
export interface HostToolkitUi {
  invoke(input: {
    sessionId: string;
    /** Additional user-selected sessions. Host resolves and authorizes each workspace separately. */
    relatedSessionIds?: readonly string[];
    toolkit: string;
    function: string;
    args?: unknown;
  }): Promise<unknown>;
}
