/** Backend-only Canvas view publication; the Host resolves the persisted session workspace. */
export interface HostCanvasPublicationScope {
  readonly sessionId: string;
  readonly resourceId: string;
}
export interface HostCanvasPublicationIdentity extends HostCanvasPublicationScope {
  readonly operationId: string;
  readonly inputHash: string;
}
export interface HostCanvasPublicationScene {
  elements: Array<{ id: string; type: string; x: number; y: number; [field: string]: unknown }>;
  files?: Record<
    string,
    { id: string; mimeType: string; created: number; [field: string]: unknown }
  >;
}
export interface HostCanvasPublicationsLike {
  readTransfer?(input: HostCanvasTransfer): Promise<{ revision: string } | undefined>;
  transfer?(
    input: HostCanvasTransfer & {
      expectedRevision: string;
      scene: HostCanvasPublicationScene;
    }
  ): Promise<{ status: 'conflict' } | { status: 'applied'; revision: string }>;
  read(
    input: HostCanvasPublicationScope
  ): Promise<{ revision: string; scene: HostCanvasPublicationScene }>;
  readPublication(input: HostCanvasPublicationIdentity): Promise<{ revision: string } | undefined>;
  publish(
    input: HostCanvasPublicationIdentity & {
      readonly expectedRevision: string;
      readonly scene: HostCanvasPublicationScene;
      readonly changedElementIds: string[];
    }
  ): Promise<{ status: 'conflict' } | { status: 'applied'; revision: string }>;
}

/** Destination is a single directory under the Host-resolved destination session workspace. */
export interface HostCanvasTransfer {
  operationId: string;
  inputHash: string;
  kind: 'copy' | 'move';
  source: HostCanvasPublicationScope;
  destination: HostCanvasPublicationScope & { directoryName: string };
}
