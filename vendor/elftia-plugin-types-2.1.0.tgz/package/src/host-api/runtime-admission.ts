/** Backend coordination with the Host's durable runtime authority, not a filesystem grant. */
export interface HostRuntimeAdmissionInput {
  kind: 'agent' | 'cli' | 'media' | 'native' | 'analysis' | 'write';
  paths: readonly string[];
  ownerId?: string;
  unscoped?: boolean;
}

export interface HostRuntimeProducerControl {
  producerId: string;
  inspect(): Promise<'running' | 'terminated' | 'unknown'>;
  stopAndSettle(): Promise<'terminated' | 'unknown'>;
}

export interface HostRuntimeAdmissionLease {
  assertCurrent(): Promise<void>;
  release(): void | Promise<void>;
  retainUnknown(): void | Promise<void>;
  registerProducer(control: HostRuntimeProducerControl): Promise<void>;
  settleProducer(producerId: string): Promise<void>;
}

export interface HostRuntimeExclusion {
  assertQuiescent(): Promise<void>;
  /** Re-pin created endpoints after the owner's verifier; paths and existing ancestors cannot change. */
  transition?(verify: () => Promise<void>): Promise<void>;
  release(): void | Promise<void>;
}

/** Backend-only launch. The platform owns the entire child tree and its durable exit proof. */
export interface HostManagedProcessInput {
  operationId: string;
  command: string;
  args: readonly string[];
  cwd: string;
  paths: readonly string[];
  env?: Readonly<Record<string, string>>;
  input?: string;
  timeoutMs: number;
  maxOutputBytes: number;
}
export interface HostManagedProcessResult {
  exitCode: number | null;
  exited: boolean;
  cancelled: boolean;
  timedOut: boolean;
  outputLimited: boolean;
  stdoutBase64: string;
}

/** Producer callbacks stay in the executing process; all hosts share one durable journal. */
export interface HostRuntimeAdmissionLike {
  runProcess?(input: HostManagedProcessInput): Promise<HostManagedProcessResult>;
  cancelProcess?(operationId: string): Promise<void>;
  acquire(input: HostRuntimeAdmissionInput): Promise<HostRuntimeAdmissionLease>;
  exclude(input: {
    paths: readonly string[];
    /** Stable operation identity permits recovery after the owning process has exited. */
    operationId?: string;
    recovery?: boolean;
    /** Settle only these producer kinds; active agents and other writers continue to veto. */
    settleKinds?: readonly ('native' | 'analysis' | 'media')[];
  }): Promise<HostRuntimeExclusion>;
}
