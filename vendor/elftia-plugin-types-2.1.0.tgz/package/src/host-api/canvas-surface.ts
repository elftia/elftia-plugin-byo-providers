import type { HostComponentType } from './_shared';

/** The Host resolves the scene from the session's resource binding. */
export interface HostCanvasSurfaceProps {
  sessionId: string;
  locale?: 'en' | 'zh' | 'ja';
}

/** Reuses the Host Canvas editor and persistence, including plugin publications. */
export interface HostCanvasSurface {
  Board: HostComponentType<HostCanvasSurfaceProps>;
}
