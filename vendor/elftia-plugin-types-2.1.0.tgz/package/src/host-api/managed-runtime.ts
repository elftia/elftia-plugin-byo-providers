/** Main-context managed-runtime discovery and execution admission. */
export interface HostManagedRuntimeLike {
  /** Legacy v1.43 discovery hint only; existence does not authorize execution. */
  resolvePreparedDir(id: string): string | null;

  /**
   * Prepare if needed and freshly verify private Host receipts and content.
   * Consumers must await this and explicitly pass the returned root to their
   * launcher. Older Hosts may omit it; execution consumers must fail closed.
   * Rejects when unavailable, untrusted, or requiring repair (v1.117).
   */
  ensurePrepared?(id: string): Promise<string>;
}
