/**
 * host-api/canvas-scene.ts — `HostCanvasSceneLike`, the
 * `host.services.canvasScene` capability port (`canvas-host-adapter-ports`
 * T0b, host-API v1.59; owner ruling O13).
 *
 * The scene read + the node-flow scene verbs — `getState` / `projectFlow` /
 * `clearFlow`, the same semantics as the core `canvas:getState` /
 * `canvas:flow.project` / `canvas:flow.clear` channels — thin-forwarded
 * through the core host dispatch (the SAME registered handlers the renderer
 * IPC path uses; one execution model, no second path).
 *
 * ── HOST-MINTED OPAQUE SESSION HANDLES (the anti-forgery crux, O13) ──
 * Session identity crosses this port ONLY as a
 * {@link HostCanvasSessionHandle}: an opaque host-minted token
 * (`csv1:<64 hex>`, `crypto.randomBytes(32)`-grade — the `CanvasMcpServer`
 * bearer-token precedent) resolved by a bridge-side registry. The port
 * exposes NO minting or resolution method — a caller can never turn a raw
 * session id into a handle through `host.services`, so a handle minted for
 * session A can never be used to read session B, and a revoked handle stops
 * working. Minting is HOST-SIDE wiring (the S09 child-2 toolkit host, which
 * sources the id from its host-injected context).
 *
 * ── NO DATA MASK (O13, explicit) ──
 * Scene data returned by `getState` is NOT masked — the ruling scopes
 * masking to secrets/paths (the mediaStorage port), not to canvas scene
 * payloads. Results are opaque structural records; the consumer re-narrows.
 *
 * ── WHAT IS DELIBERATELY NOT HERE ──
 * No raw element-mutation primitive (`removeElements` / `applyMutation` …)
 * crosses: the guard lives at the VERB boundary (the core `ports/canvas-scene`
 * discipline), and the flow verbs take ONLY the handle — the clearable set is
 * computed behind the core seam from the `customData.flowEdge` owner tag, so
 * no caller can ask the host to delete something the projection does not own.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it. Structural lower
 * bounds only — no `@main`/`@shared` import.
 *
 * @module @elftia/plugin-types/host-api/canvas-scene
 */

/**
 * An OPAQUE, HOST-MINTED canvas session handle. Runtime form
 * `csv1:<64 lowercase hex>` (a version prefix + 256 bits of randomness —
 * unforgeable and never derived from the session id it names). Branded so a
 * bare `string` (a raw session id, a guess) is not assignable where a handle
 * is required; only the host-side registry mints and resolves these, and the
 * port exposes no mint/resolve verb of its own.
 */
declare const hostCanvasSessionHandleBrand: unique symbol;
export type HostCanvasSessionHandle = string & {
  readonly [hostCanvasSessionHandleBrand]: 'HostCanvasSessionHandle';
};

/**
 * A canvas scene (or flow-verb) result — an OPAQUE structural record,
 * deliberately NOT masked (owner ruling O13: the ruling scopes masking to
 * secrets/paths, not scene data). The consumer re-narrows the fields it
 * reads; the canonical shapes live behind the core seam.
 */
export type HostCanvasSceneData = { readonly [key: string]: unknown };

/**
 * `host.services.canvasScene` — the scene + node-flow verb port. Every method
 * takes the HOST-MINTED opaque handle (never a raw session id), resolves it
 * bridge-side, and dispatches the matching core channel with
 * `{ sessionId }` — the same registered handlers the renderer IPC path uses.
 * A never-minted / revoked handle (or a raw session id string) rejects
 * BEFORE any core dispatch.
 */
export interface HostCanvasSceneLike {
  /**
   * Read the session's canvas scene (normalized, `canvas:getState`
   * semantics). Returns the scene data UNMASKED (O13).
   */
  getState(handle: HostCanvasSessionHandle): Promise<HostCanvasSceneData>;
  /**
   * Materialize the session's node-flow projection onto the scene
   * (`canvas:flow.project` semantics — derive + write in one verb, the
   * clearable set computed behind the seam).
   */
  projectFlow(handle: HostCanvasSessionHandle): Promise<HostCanvasSceneData>;
  /**
   * Clear the session's node-flow projection (`canvas:flow.clear` semantics —
   * removes ONLY the flow-owned elements, never a caller-supplied set).
   */
  clearFlow(handle: HostCanvasSessionHandle): Promise<HostCanvasSceneData>;
}
