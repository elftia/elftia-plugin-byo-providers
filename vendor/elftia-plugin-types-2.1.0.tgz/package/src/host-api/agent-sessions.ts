import type { HostUnregister } from './_shared';

/** A plugin supplies identity and policy; the host owns standard session execution. */
export interface HostPluginAgentDefinition {
  agentId: string;
  name: string;
  description?: string;
  systemPrompt: string;
  capabilities: string[];
  engineConfig?: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
}

export interface HostPluginAgentTurn {
  agentId: string;
  requestId: string;
  prompt: string;
  sessionId?: string;
  providerId?: string;
  model?: string;
}

export interface HostPluginAgentTerminal {
  status: 'completed' | 'failed' | 'cancelled' | 'outcome_unknown';
  response?: string;
  error?: string;
}

export interface HostPluginAgentRunRef {
  agentId: string;
  dbSessionId: string;
  requestId: string;
}

/**
 * In-process Desktop port. Agent IDs are restricted to `<pluginId>:<localId>`.
 * Registrations and running turns are revoked when the owning plugin unloads.
 * Plugins persist admission/deduplication before start; prepare never runs a model.
 * This port is absent in the extension process and Server hosts.
 */
export interface HostAgentSessions {
  register(definition: HostPluginAgentDefinition): HostUnregister;
  prepare(input: HostPluginAgentTurn): Promise<{ dbSessionId: string }>;
  start(
    input: HostPluginAgentTurn & { dbSessionId: string },
    onTerminal: (result: HostPluginAgentTerminal) => Promise<void>,
    shouldStart?: () => Promise<boolean>
  ): Promise<void>;
  inspect(input: HostPluginAgentRunRef): Promise<HostPluginAgentTerminal | null>;
  cancel(input: HostPluginAgentRunRef): Promise<boolean>;
}
